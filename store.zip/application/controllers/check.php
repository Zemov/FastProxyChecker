<?
session_start();
class check extends FE_Controller {
	function __Construct(){
        parent::__construct();
   		$this->load->model('order_model');
		$this->load->model('goods_model');
   }
	
	public function index(){
	if(!empty($_SESSION['id'])){$this->data['subview'] = 'check';}else{redirect('/');exit();}
	
	$order = $this->order_model->get_by(array('id' => $_SESSION['id']),TRUE);	
	$this->data['order'] = $order;
	$this->data['check'] = $_SESSION['check_url'];
	$this->data['op'] = $_SESSION['op'];
    $this->load->view('main_layout',$this->data);
	}

}
?>