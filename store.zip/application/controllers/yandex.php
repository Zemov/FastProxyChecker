<?
class yandex extends FE_Controller {
	function __Construct(){
        parent::__construct();
   		$this->load->model('order_model');
		$this->load->model('goods_model');
   }
	
	public function index()
	{
		$secret_key = config_item('yad_token');

$sha1 = sha1( $_POST['notification_type'] . '&'. $_POST['operation_id']. '&' . $_POST['amount'] . '&643&' . $_POST['datetime'] . '&'. $_POST['sender'] . '&' . $_POST['codepro'] . '&' . $secret_key. '&' . $_POST['label'] );
if ($sha1 != $_POST['sha1_hash'] ){
  echo "ошибка";
  exit();
}
           $status="Успешно!";
           $id=$_POST['label'];
           $money=number_format($_POST['withdraw_amount'], 2, '.', '');
           $tranid=$_POST["operation_id"];
           $flow="in";
           $paysystem="ym";
           $ymfrom=$_POST['sender'];

		   $cpnquery = $this->db->query("SELECT * FROM orders WHERE id LIKE '$id'");
		   $goods = $cpnquery->row();
		   $item = $this->goods_model->get($goods->item_id);
           if($money > 1){if($money >= $goods->price){
		   $sum = $goods->price;   
		   }else{exit;}}else{exit;}
            $bill = $id;
            $retname = $bill.'.txt';
			$savebill = $bill;
			$bill = 'Оплата #'.$bill;
							if($item->sell_method == 0)
							{
								$count = $goods->count;
								$filename = preg_replace('/[^\p{L}\p{N}\s]/u','', md5(config_item('encryption_key').$item->name));
								$uppath = './assets/uploads/'.preg_replace('/[^\p{L}\p{N}\s]/u','', md5(config_item('encryption_key').$filename.$item->name)).'/';
								$goodse = file($uppath.$filename,FILE_IGNORE_NEW_LINES);
								$paidgoods = implode("\r\n",array_splice($goodse, 0, $count));
								$goodse = implode("\r\n",$goodse);
								$smbill = md5(config_item('encryption_key').$savebill).'.txt';
								file_put_contents($uppath.$filename,$goodse);
								file_put_contents('./assets/uploads/orders/'.$smbill,$paidgoods);
								$saveord['goods'] = $smbill;
							}elseif($item->sell_method == 1){
								$uppath = './assets/uploads/'.preg_replace('/[^\p{L}\p{N}\s]/u','', md5(config_item('encryption_key').$item->goods.$item->name)).'/'.$item->goods;
								$retname = $item->goods;
								$paidgoods = file_get_contents($uppath);
							}
							$saveord['paid'] = TRUE;
							$this->order_model->save($saveord,$goods->id);		   
		   
		   
exit();
	}

}
?>