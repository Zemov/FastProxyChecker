<?php
class qiwi extends FE_Controller {
	function __Construct() {
        parent::__construct();
    }
	public function index()
	{	
     $this->load->helper('qiwi_helper');
	 echo result_qiwi();
	}
}
?>