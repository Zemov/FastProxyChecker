<?php
class config extends Admin_Controller {
	function __Construct() {
        parent::__construct();
		$this->load->model('siteconfig');
    }
	public function index()
	{
		$rules = $this->siteconfig->rules;
		$this->form_validation->set_rules($rules);
		if($this->form_validation->run() == TRUE) {
			$this->load->library('encrypt');
			$data = $this->siteconfig->array_from_post(array('site_name','sitedescription','metadescr','yad_wallet','yad_token','qiwi_num','qiwi_pass'));
			$this->siteconfig->update_config($data);
			$this->data['ok'] = TRUE;
			$this->data['subview'] = 'admin/config';
			$this->load->view('admin/layout_main',$this->data);
		}
		else 
		{
		$this->data['subview'] = 'admin/config';
		$this->load->view('admin/layout_main',$this->data);
		}
	}
		
	}              
	
?>