<div data-backdrop="false" class="modal fade" id="paymodal">
<div class="modal-dialog">
  <div class="modal-content">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      <h4 class="modal-title">Оплата</h4>
    </div>
    <div class="modal-body">
    <table class="paytable">
	  <tr>
		  <td>Товар:</td>
		  <td class="payitem">...</td>
	  </tr>
	  <tr>
		  <td>Кол-во:</td>
		  <td class="paycount">...</td>
	  </tr>
	  <tr>
		  <td>К оплате:</td>
		  <td class="payprice"><input value="" style="border: 0;" onclick=" $(this).select();" readonly><i></i></td>
	  </tr>
	  <tr>
		  <td>Кошелек для платежа:</td>
		  <td class="payfund"><input value="" style="border: 0;" onclick=" $(this).select();" readonly></td>
	  </tr>
	  <tr>
		  <td>Примечание к платежу:</td>
		  <td class="paybill"><input value="" style="border: 0;" onclick="$(this).select();" readonly></td>
	  </tr>
	</table>
    </div>
	 <div id="keeperLink"></div>
    <div class="payfoot modal-footer">
      <button type="button" onclick="" data-loading-text="Проверяем..." class="checkpaybtn btn btn-primary">Проверить</button>
    </div>
  </div>
</div>
</div>

<? if(count($items)): foreach($items as $item): ?>
<div class="col-md-3">
				<div class="product-box">
					<div class="product-head">
						<div class="procut-price">
							<h2><? echo $item->price_rub; ?> руб. за 1 шт.</h2>
							<p><? echo $item->price_dlr; ?> usd. за 1 шт.</p>
						</div>
						<div class="product-ico">
							<? echo empty($item->iconurl) ? '' : '<img class="iconurl" src="'.$item->iconurl.'" alt="'.$item->name.'"/>'; ?>
						</div>
					</div>
					<div class="product-body">
						<p><? echo $item->name; ?></p>
					</div>
					<div class="product-button">
						<a href="<? echo '/item/'.$item->id; ?>">Подробнее</a>
					</div>
				</div>
			</div>
<? endforeach; ?>
<? else: ?>
	Товары отсутствуют
<? endif; ?>