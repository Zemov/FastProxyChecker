<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
									<h6 class="panel-title txt-dark">Заказы</h6>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="panel-wrapper collapse in">
								<div class="panel-body row pa-0">
									<div class="table-wrap">
										<div class="table-responsive">
											<table class="table display product-overview border-none" id="employee_table">
												<thead>
													<tr>
														<th>ID</th>
														<th>Примичание</th>
														<th>Дата</th>
														<th>Товар</th>
														<th>Кол-во</th>
														<th>Цена</th>
														<th>E-mail</th>
														<th>IP</th>
														<th>Оплачен</th>
														<th>Скачать</th>
													</tr>
												</thead>
												<tbody>
													<? if(count($orders)): foreach($orders as $order): ?>
													<tr>
														<td><? echo $order->id; ?></td>
														<td><? echo $order->bill; ?></td>
														<td style="font-size:11px;"><? echo date('d-m-Y H:i:s',$order->date); ?></td>
														<td style="font-size:11px;"><? echo $order->name; ?></td>
														<td><? echo $order->count; ?></td>
														<td><? echo $order->price.' '.$order->fund; ?></td>
														<td><? echo $order->email; ?></td>
														<td><? echo $order->ip_address; ?></td>
														<td><? echo $order->paid ? 'Да' : 'Нет' ?></td>
														<td><a title="Скачать купленный товар" href="/admin/orders/getorder/<? echo $order->id ;?>" class="fa fa-cloud-download"></span></td>
													</tr>
													<? endforeach; ?>
													<? else: ?>
													<tr>
														<td colspan="10">Заказы отсутствуют</td>
													</tr>
													<? endif; ?>
												</tbody>
											</table>
										</div>
									</div>	
								</div>	
							</div>
						</div>