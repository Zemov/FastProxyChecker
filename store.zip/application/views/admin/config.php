<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
									<h6 class="panel-title txt-dark">Настройки скрипта</h6>
								</div>
								<div class="clearfix"></div>
							</div>
							<? if(isset($error)) {
								echo $error;
							}
								elseif(isset($ok)) {
									echo '<div class="alert alert-success">Данные успешно сохранены!</div>';
								}
								?>
							<? echo validation_errors(); ?>
							<? echo form_open_multipart(); ?>
							<div class="panel-wrapper collapse in">
								<div class="panel-body row pa-0">
									<div class="table-wrap">
										<div class="table-responsive">
											<table class="table display product-overview border-none" id="employee_table">
												<tbody>
													<tr>
														<td>Название сайта:</td>
														<td><? echo form_input('site_name', set_value('site_name', $this->config->item('site_name')),'class="form-control"'); ?></td>
													</tr>
													<tr>
														<td>Блок информации:</td>
														<td><? echo form_input('sitedescription', set_value('sitedescription', $this->config->item('sitedescription')),'class="form-control"'); ?></td>
													</tr>
													<tr>
														<td>Мета-описание сайта:</td>
														<td><? echo form_textarea('metadescr', set_value('metadescr', $this->config->item('metadescr')),'class="form-control"'); ?></td>
													</tr>
													<tr>
														<td>Яндекс (Кашелёк):</td>
														<td><? echo form_input('yad_wallet', set_value('yad_wallet', $this->config->item('yad_wallet')),'class="form-control"'); ?></td>
													</tr>
													<tr>
														<td>Яндекс (Секретный ключ):</td>
														<td><? echo form_input('yad_token', set_value('yad_token', $this->config->item('yad_token')),'class="form-control"'); ?></td>
													</tr>	
													<tr>
														<td>QIWI (Номер без +):</td>
														<td><? echo form_input('qiwi_num', set_value('qiwi_num', $this->config->item('qiwi_num')),'class="form-control"'); ?></td>
													</tr>
													<tr>
														<td>QIWI (Токен):</td>
														<td><? echo form_input('qiwi_pass', set_value('qiwi_pass', $this->config->item('qiwi_pass')),'class="form-control"'); ?></td>
													</tr>
													<tr>
														<td></td>
														<td><? echo form_submit('submit','Сохранить','value="upload" class="btn btn-primary"'); ?></td>
													</tr>
												</tbody>
											</table>
											<? echo form_close(); ?>
										</div>
									</div>	
								</div>	
							</div>
						</div>