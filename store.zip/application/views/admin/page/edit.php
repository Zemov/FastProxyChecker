<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
									<h6 class="panel-title txt-dark"><? echo empty($page->id) ? 'Добавить новую страницу' : 'Редактировать страницу: ' . $page->title; ?></h6>
								</div>
								<div class="clearfix"></div>
							</div>
							<? echo validation_errors(); ?>
							<? echo form_open(); ?>
							<div class="panel-wrapper collapse in">
								<div class="panel-body row pa-0">
									<div class="table-wrap">
										<div class="table-responsive">
											<table class="table display product-overview border-none" id="employee_table">
												<tbody>
													<tr>
														<td>Заголовок:</td>
														<td><? echo form_input('title', set_value('title', $page->title),'class="form-control"'); ?></td>
													</tr>
													<tr>
														<td>Альт. заголовок:</td>
														<td><? echo form_input('slug', set_value('slug', $page->slug),'class="form-control"'); ?></td>
													</tr>
													<tr>
														<td>Текст:</td>
														<td><? echo form_textarea('body', set_value('body', $page->body), 'class="textarea_editor form-control"'); ?></td>
													</tr>
													<tr>
														<td></td>
														<td><? echo form_submit('submit','Сохранить','class="btn btn-primary"'); ?></td>
													</tr>
												</tbody>
											</table>
											<? echo form_close(); ?>
										</div>
									</div>	
								</div>	
							</div>
						</div>