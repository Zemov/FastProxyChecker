<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
									<h6 class="panel-title txt-dark">Страницы</h6>
								</div>
								<div class="pull-right">
									<? echo anchor('admin/page/edit','<i class="glyphicon glyphicon-plus"></i> Добавить страницу',array('class'=>'pull-right btn btn-small btn-primary')); ?>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="panel-wrapper collapse in">
								<div class="panel-body row pa-0">
									<div class="table-wrap">
										<div class="table-responsive">
											<table class="table display product-overview border-none" id="employee_table">
												<thead>
													<tr>
														<th>Заголовок</th>
														<th>Изменить</th>
														<th>Удалить</th>
													</tr>
												</thead>
												<tbody>
												<? if(count($pages)): foreach($pages as $page): ?>
												<tr>
													<td><? echo anchor('admin/page/edit/'.$page->id, $page->title); ?></td>
													<td><? echo btn_edit('admin/page/edit/'.$page->id); ?></td>
													<td><? echo btn_delete('admin/page/delete/'.$page->id); ?></td>
												</tr>
												<? endforeach; ?>
												<? else: ?>
												<tr>
													<td colspan="3">Записи отсутствуют</td>
												</tr>
												<? endif; ?>
												</tbody>
											</table>
										</div>
									</div>	
								</div>	
							</div>
						</div>