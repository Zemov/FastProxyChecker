
<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
									<h6 class="panel-title txt-dark">Товары</h6>
								</div>
								<div class="pull-right">
									<? echo anchor('admin/goods/edit','Добавить товар',array('class'=>'pull-right btn btn-small btn-primary')); ?>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="panel-wrapper collapse in">
								<div class="panel-body row pa-0">
									<div class="table-wrap">
										<div class="table-responsive">
											<table class="table display product-overview border-none" id="employee_table">
												<thead>
													<tr>
														<th>ID</th>
														<th>Название</th>
														<th>Кол-во</th>
														<th>Цена</th>
														<th>Изменить</th>
														<th>Удалить</th>
													</tr>
												</thead>
												<tbody>
													<? if(count($goods)): foreach($goods as $good): ?>
													<tr>
														<td><? echo $good->id; ?></td>
														<td><? echo $good->name; ?></td>
														<td><? echo $good->count; ?></td>
														<td><? echo $good->price_rub.' <span class="rur">p<span>уб.</span></span> | '.$good->price_dlr.' $'.' за 1шт.'; ?></td>
														<td>
															<? echo btn_edit('admin/goods/edit/'.$good->id); ?>
														</td>
														<td><? echo btn_delete('admin/goods/delete/'.$good->id); ?></td>
													</tr>
													<? endforeach; ?>
													<? else: ?>
													<tr>
														<td colspan="6">Товары отсутствуют</td>
													</tr>
													<? endif; ?>
												</tbody>
											</table>
										</div>
									</div>	
								</div>	
							</div>
						</div>