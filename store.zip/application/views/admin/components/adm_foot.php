	<footer class="footer container-fluid pl-30 pr-30">
				<div class="row">
					<div class="col-sm-12">
						<p>2018 &copy; <? echo config_item('site_name'); ?> <a href="https://vk.com/id511179228">Дизайн и верстка B5moke</a></p>
					</div>
				</div>
			</footer>
			<!-- /Footer -->
			
		</div>
        <!-- /Main Content -->

    </div>
  	<script src="/assets/Dark/vendors/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/assets/Dark/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    
	<!-- Data table JavaScript -->
	<script src="/assets/Dark/vendors/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
	
	<!-- Slimscroll JavaScript -->
	<script src="/assets/Dark/dist/js/jquery.slimscroll.js"></script>
	
	<!-- simpleWeather JavaScript -->
	<script src="/assets/Dark/vendors/bower_components/moment/min/moment.min.js"></script>
	<script src="/assets/Dark/vendors/bower_components/simpleWeather/jquery.simpleWeather.min.js"></script>
	<script src="/assets/Dark/dist/js/simpleweather-data.js"></script>
	
	<!-- Progressbar Animation JavaScript -->
	<script src="/assets/Dark/vendors/bower_components/waypoints/lib/jquery.waypoints.min.js"></script>
	<script src="/assets/Dark/vendors/bower_components/jquery.counterup/jquery.counterup.min.js"></script>
	
	<!-- Fancy Dropdown JS -->
	<script src="/assets/Dark/dist/js/dropdown-bootstrap-extended.js"></script>
	
	<!-- Sparkline JavaScript -->
	<script src="/assets/Dark/vendors/jquery.sparkline/dist/jquery.sparkline.min.js"></script>
	
	<!-- Owl JavaScript -->
	<script src="/assets/Dark/vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>
	
	<!-- Toast JavaScript -->
	
	<!-- EChartJS JavaScript -->
	<script src="/assets/Dark/vendors/bower_components/echarts/dist/echarts-en.min.js"></script>
	<script src="/assets/Dark/vendors/echarts-liquidfill.min.js"></script>
	
	<!-- Switchery JavaScript -->
	<script src="/assets/Dark/vendors/bower_components/switchery/dist/switchery.min.js"></script>
	
	<!-- Init JavaScript -->
	<script src="/assets/Dark/dist/js/init.js"></script>
	<script src="/assets/Dark/dist/js/dashboard-data.js"></script>
  </body>
</html>