<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
									<h6 class="panel-title txt-dark">Список промо-кодов</h6>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="panel-wrapper collapse in">
								<div class="panel-body row pa-0">
									<div class="table-wrap">
										<div class="table-responsive">
											<table class="table display product-overview border-none" id="employee_table">
												<thead>
													<tr>
														<th>Промо-код</th>
														<th>Использован <? echo $coupon->mayused==0 ? '' : '(раз)';?> </th>
													</tr>
												</thead>
												<tbody>
												<?
													foreach ($coupon->coupon as $key => $value) {
														echo '<tr>';
														echo '<td>'.$value['coupon'].'</td>';
														echo '<td>'.$value['used'].'</td>';
														echo '</tr>';
													}
			
												?>
												</tbody>
											</table>
										</div>
									</div>	
								</div>	
							</div>
						</div>