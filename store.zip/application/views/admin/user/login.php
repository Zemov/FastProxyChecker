<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
									<h6 class="panel-title txt-dark">Логин</h6>
								</div>
								<div class="pull-right">
									<p>Войдите используя свои данные</p>
								</div>
								<div class="clearfix"></div>
							</div>
							<? echo validation_errors(); ?>
							<? echo form_open(); ?>
							<div class="panel-wrapper collapse in">
								<div class="panel-body row pa-0">
									<div class="table-wrap">
										<div class="table-responsive">
											<table class="table display product-overview border-none" id="employee_table">
												<tbody>
													<tr>
														<td>E-mail:</td>
														<td><? echo form_input('email', set_value('email', $this->config->item('email')),'class="form-control"'); ?></td>
													</tr>
													<tr>
														<td>Пароль:</td>
														<td><? echo form_password('password', set_value('password', $this->config->item('password')),'class="form-control"'); ?></td>
													</tr>
													<tr>
														<td>Введите код:</td>
														<td><img src="/captcha.png"></td>
													</tr>
													<tr>
														<td></td>
														<td><? echo form_input('captcha', set_value('captcha', $this->config->item('captcha')),'class="form-control"'); ?></td>
													</tr>
													<tr>
														<td></td>
														<td><? echo form_submit('submit','Войти','class="btn btn-primary"'); ?></td>
													</tr>
												</tbody>
											</table>
											<? echo form_close(); ?>
										</div>
									</div>	
								</div>	
							</div>
						</div>