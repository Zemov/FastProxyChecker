<!DOCTYPE html>
<html>
  <head>
    <title><? echo $title.config_item('site_name'); ?></title>
	<meta charset="utf-8" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="<? echo $this->config->item('metadescr'); ?>">
	<meta name="keywords" content="Teg"/>
	<link rel="shortcut icon" href="/assets/img/favicon.ico" />
    <link href="<? echo site_url('/assets/css/bootstrap.min.css'); ?>" rel="stylesheet" media="screen">
    <link href="<? echo site_url('/assets/style.css'); ?>" rel="stylesheet" media="screen">
    <link href="<? echo site_url('/assets/css/jquery.toastmessage.css'); ?>" rel="stylesheet" media="screen">
    <link href="<? echo site_url('/assets/css/font-awesome.min.css'); ?>" rel="stylesheet" media="screen">
	<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet">
	<script src="http://code.jquery.com/jquery.js"></script>
	<script type="text/javascript" src="http://code.jquery.com/ui/1.10.0/jquery-ui.js"></script>
	<script src="<? echo site_url('assets/js/bootstrap.min.js');?>"></script>
	<script src="<? echo site_url('assets/js/respond.js');?>"></script>
	<script src="<? echo site_url('assets/js/app.js');?>"></script>
	<script src="<? echo site_url('assets/js/jquery.toastmessage.js');?>"></script>
 </head>
 