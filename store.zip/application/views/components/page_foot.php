	<footer>
		<div class="container-fluid background-footer">
			<div class="container">
				<h1><? echo config_item('site_name'); ?></h1>
			</div>
		</div>
	</footer>
</body>
</html>