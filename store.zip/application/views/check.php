<div class="panel">

  <div class="panel-body">
      <div class="row">
<div class="col-lg-6">
		<label class="control-label">Название:</label>
		 <input type="text" class="form-control input-small" value="<?=$order->name;?>" readonly>	
</div>
<div class="col-lg-2">
		<label class="control-label">Ценна:</label>
		 <input type="text" class="form-control input-small" value="<?=$order->price;?>" readonly>	
</div>		
        <div class="col-lg-2" style="margin-top: 9px;">
		<button type="button" onclick="window.open('<?=$op;?>')" class="btn btnbuy btn-primary btn-block">Оплатить</button>
        </div>
        <div class="col-lg-2" style="margin-top: 9px;">
		<button type="button" onclick="checkpay('<?=$check;?>')" data-loading-text="Проверяем..." class="checkpaybtn btn btnbuy btn-primary btn-block">Проверить</button>
        </div>
      </div>
  </div>
</div>