
<div data-backdrop="false" class="modal fade" id="paymodal">
<div class="modal-dialog">
  <div class="modal-content">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      <h4 class="modal-title">Оплата</h4>
    </div>
    <div class="modal-body">
    <table class="paytable">
	  <tr>
		  <td>Товар:</td>
		  <td class="payitem">...</td>
	  </tr>
	  <tr>
		  <td>Кол-во:</td>
		  <td class="paycount">...</td>
	  </tr>
	  <tr>
		  <td>К оплате:</td>
		  <td class="payprice"><input value="" style="border: 0;" onclick=" $(this).select();" readonly><i></i></td>
	  </tr>
	  <tr>
		  <td>Кошелек для платежа:</td>
		  <td class="payfund"><input value="" style="border: 0;" onclick=" $(this).select();" readonly></td>
	  </tr>
	  <tr>
		  <td>Примечание к платежу:</td>
		  <td class="paybill"><input value="" style="border: 0;" onclick="$(this).select();" readonly></td>
	  </tr>
	</table>
    </div>
	 <div id="keeperLink"></div>
    <div class="payfoot modal-footer">
      <button type="button" onclick="" data-loading-text="Проверяем..." class="checkpaybtn btn btn-primary">Проверить</button>
    </div>
  </div>
</div>
</div>

		<div class="row">
			<div class="col-md-3">
				<div class="items-ico">
					<img src="<? echo $item->iconurl; ?>">
				</div>
				<div class="item-price">
					<span style="font-size: 16px; font-weight: 700;">Цена: <? echo $item->price_rub;?> руб. за 1 шт.</span><br>
					<span>Цена: <? echo $item->price_dlr;?> $. за 1 шт.</span>
				</div>
				<div class="item-price" style="margin-top: 10px;">
					<span style="font-size: 16px; font-weight: 700;">В наличии: <? echo $item->count;?></span><br>
				</div>
			</div>
			<div class="col-md-9">
				<div class="items-line">
					<p><? echo $item->descr; ?></p>
				</div>
			</div>
		</div>
		<div class="row" id="up">
			<div class="panel">
				<a id="coupon" class="cupp">Есть промо-код?</a>
  
  <div class="hide popover_content">
	<input type="text" class="input-small form-control" id="cpn_inp" value=''>
  </div>
  <div class="panel-body">
      <div class="row">
     <div class="col-md-2">
         <? if (is_int($item->count)): ?>    
		 <label class="control-label" for="count">Кол-во:</label>		  
          <input type="text" class="form-control input-small" name="count" onkeyup="this.value=this.value.replace(/[^0-9]/g, '')">	
		<? else: ?>
		<label class="control-label" for="count">Кол-во:</label>
		 <input type="text" class="form-control input-small" name="count" value ='1' readonly>	
     	 <? endif; ?>   </div>
        <div class="col-md-4">
          <label class="control-label" for="funds">Оплата:</label>
          <select class="form-control input-small" name="funds">
              <? foreach($funds as $fund): ?>
              <option value="<? echo $fund['fundid']; ?>" data-fund="<? echo $fund['fundname']; ?>"><? echo $fund['fundname']; ?></option>
              <? endforeach; ?>
          </select>
        </div>
		<select class="form-control input-small" name="item" style='display:none'>
				<option value="<? echo $item->id; ?>" data-id="<? echo $item->id; ?>" data-min_order="<? echo $item->min_order; ?>" data-item_count="<? echo $item->count; ?>" selected></option>
			</select>
        <div class="col-md-3">
          <label class="control-label" for="email">E-mail:</label>
          <input type="email" class="form-control input-small" name="email">
        </div>
        <div class="col-md-3">
          <button onclick="sendData();" type="button" id="settinger" class="btn btnbuy btn-primary btn-block">Купить</button>
        </div>
      </div>
  </div>
</div>
		</div>
	
