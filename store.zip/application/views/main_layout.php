<? $this->load->view('components/page_head.php'); ?>

	<body>
	<header>
		<div class="container-fluid background-menu">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="menu">
							<ul>
								<li><a href="<? echo site_url('/'); ?>"><? echo config_item('site_name'); ?></a></li>
								<? foreach($pages as $page) : ?>
								<li><a href="/page/<? echo $page['slug']; ?>"> <? echo $page['title']; ?></a></li>
								<? endforeach; ?>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<div class="container-fluid background-header">
		<? if(config_item('sitedescription') != NULL): ?>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="header-text">
						<h1><? echo config_item('site_name'); ?></h1>
						<p><? echo config_item('sitedescription'); ?></p>
					</div>
				</div>
			</div>
		</div>
		<? endif; ?>
	</div>
	<div class="container" id="up">
		<div class="row">
			<? $this->load->view($subview); ?>
		</div>
	</div>
	
<? $this->load->view('components/page_foot.php'); ?>