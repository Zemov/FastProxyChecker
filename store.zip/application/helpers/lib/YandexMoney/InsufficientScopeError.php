<?php
/**
 * User: mdv
 * Date: 08.04.12
 * Time: 23:56
 */
class YM_InsufficientScopeError extends YM_Error {

}
