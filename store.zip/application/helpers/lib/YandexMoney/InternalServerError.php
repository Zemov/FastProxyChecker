<?php

class YM_InternalServerError extends YM_Error {

}
