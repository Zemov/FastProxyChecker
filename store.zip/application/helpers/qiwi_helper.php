<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
function get_qiwi($val){
if($val == '2'){
$cur = 'QW_USD';	
}else{
$cur = 'QW_RUB';	
}	
$requestType = 'GET'; 
$date1 = date('Y-m-d',strtotime('-1 day')); 
$date11 = date('H:i:s',strtotime('-1 day')); 
$start = $date1.'T'.$date11.'Z';
$date2 = date('Y-m-d',strtotime('+1 day'));
$date22 = date('H:i:s',strtotime('+1 day'));
$end = $date2.'T'.$date22.'Z';
$url = "https://edge.qiwi.com/payment-history/v1/persons/".config_item('qiwi_num')."/payments?rows=50&operation=IN&sources[0]=$cur&startDate=$start&endDate=$end";
$headers = array(
    "Accept: application/json",
    "Content-Type: application/json",
	"Authorization: Bearer ".config_item('qiwi_pass').""
);
$ch = curl_init($url);

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $requestType);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
return curl_exec($ch);
curl_close($ch);
}

function qiwi_pay($bill,$price, $val){ 	 
$operations = json_decode(get_qiwi($val));

foreach ($operations->data as $operation) {
if(number_format($operation->sum->amount, 2, '.', '') >= $price && $operation->comment == $bill && $operation->statusText == 'Success') 
{ 
return 1; 
} 
}	 
} 



function check_qiwi(){
$operat = get_qiwi(1);

		if($operat != ''){
			return true;
		}

} 
function result_qiwi(){
return get_qiwi(1);
} 
?>