<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://smtp.mail.ru';
$config['smtp_port'] = 465;
$config['smtp_user'] = 'salebot@forshop.ml';
$config['smtp_pass'] = '';
$config['charset'] = 'utf-8';
$config['wordwrap'] = TRUE;
$config['mailtype'] = 'html';
*/
