﻿<div class="box box-filter">
								<div class="box-heading"><span><center>КОНТАКТЫ</center></span></div>
									<div class="box-content">
										<ul class="box-filter">
							<? echo config_item('site_infokontakt'); ?>						
																				
																				</ul>
									
									</div>
							</div>
							