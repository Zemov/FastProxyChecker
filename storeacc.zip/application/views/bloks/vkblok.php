﻿<div class="box box-filter">
								<div class="box-heading"><span><center>Группа ВК</center></span></div>
									<div class="box-content">
<script type="text/javascript" src="//vk.com/js/api/openapi.js?115"></script>

<!-- VK Widget -->
<div id="vk_groups"></div>
<script type="text/javascript">
VK.Widgets.Group("vk_groups", {mode: 0, width: "200", height: "360", color1: 'FFFFFF', color2: '2B587A', color3: '5B7FA6'}, <? echo config_item('vkblok'); ?>);
</script>										
										<ul class="box-filter">

																				
																				</ul>
									
									</div>
							</div>
							