﻿<?php
    $sql = "SELECT * FROM `goods` WHERE type_Item = '2' ORDER BY id DESC LIMIT $pplimit";
    $query = mysql_query($sql);

    if(!mysql_num_rows($query)) 
        echo "Временно Нету Распродажы";
    else
    {
        while($row = mysql_fetch_assoc($query))
        {  
            echo '<div class="b-poster"><div class="coast rpsn">';
            echo $row['price_rub'];
            echo '</div><div class="title"><b>';
            echo $row['name'];
            echo '</b></div><br>';
	    echo '<td><a style="color: #FFFFFF;" href="/product/'. $row['id'] .'"><img style="margin-top: -20px;height: 88px; width: 188px;" src="'. $row['iconurl'] .'" width=\"120\" height=\"100\" /></td>';
            echo '</div>';
	   
        }
      }
?>  