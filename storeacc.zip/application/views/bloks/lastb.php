﻿<?php
    $sql = "SELECT * FROM `orders` WHERE paid = '1' ORDER BY id DESC LIMIT $pplimit";
    $query = mysql_query($sql);

    if(!mysql_num_rows($query)) 
        echo "У нас ещё не кто не покупал";
    else
    {
        while($row = mysql_fetch_assoc($query))
        {  
            echo '<div style="margin-bottom: 0px;" class="b-poster"><div class="coast rpsn">';
            echo $row['price'];
	    echo '<i>';
            echo $row['fund'];
	    echo '<i>';
	    date_default_timezone_set('Europe/Moscow');
            echo date('d-m H:i',$row['date']);
            echo '</i></i></div><div class="title"><b>';
            echo $row['name'];
            echo '</b></div><br>';
	    echo '<td><a href="/product/'. $row['item_id'] .'"><img style="margin-top: -20px;height: 88px; width: 188px;" src="'. $row['photo'] .'" width=\"120\" height=\"100\" /></td>';
            echo '</div><br>';
        }
      }
?>  