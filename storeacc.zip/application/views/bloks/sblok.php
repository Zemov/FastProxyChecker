﻿<div class="box box-filter">
								<div class="box-heading"><span><center>Счетчик Сайта</center></span></div>
									<div class="box-content">
<!-- Yandex.Metrika informer -->
<a href="https://metrika.yandex.ru/stat/?id=<? echo config_item('skod'); ?>&amp;from=informer"
target="_blank" rel="nofollow"><img src="//bs.yandex.ru/informer/<? echo config_item('skod'); ?>/3_1_FFFFFFFF_EFEFEFFF_0_pageviews"
style="width:88px; height:31px; border:0;" alt="Яндекс.Метрика" title="Яндекс.Метрика: данные за сегодня (просмотры, визиты и уникальные посетители)" onclick="try{Ya.Metrika.informer({i:this,id:<? echo config_item('skod'); ?>,lang:'ru'});return false}catch(e){}"/></a>
<!-- /Yandex.Metrika informer -->

<!-- Yandex.Metrika counter -->
<script type="text/javascript">
(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter<? echo config_item('skod'); ?> = new Ya.Metrika({id:<? echo config_item('skod'); ?>,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true});
        } catch(e) { }
    });

    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f, false);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="//mc.yandex.ru/watch/<? echo config_item('skod'); ?>" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
										<ul class="box-filter">

																				
																				</ul>
									
									</div>
							</div>
							