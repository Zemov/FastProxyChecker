﻿<div class="box box-filter">
									<div class="box-content">
									<div class="list-group">
										<ul class="box-filter">
<?php
$pplimit = config_item('pplimit');
$ppcolor = config_item('ppcolor');
include "lastb.php";
?>
																				
																				</ul>
									
									</div>
							</div>
</div>
<style>
.list-group{padding-left:0;margin-bottom:5px;background-color:#fff}.list-group-item{position:relative;display:block;padding:5px 25px 1px 10px;margin-bottom:-1px;border:1px solid #ddd}.list-group-item>.badge{float:right;margin-right:-15px}.list-group-item-heading{margin-top:0;margin-bottom:5px}.list-group-item-text{margin-bottom:0;line-height:1.3}a.list-group-item .list-group-item-heading{color:#333}a.list-group-item .list-group-item-text{color:#555}a.list-group-item:hover,a.list-group-item:focus{text-decoration:none;background-color:#f5f5f5}a.list-group-item.active{z-index:2;color:#fff;background-color:#2fa4e7;border-color:#2fa4e7}a.list-group-item.active .list-group-item-heading{color:inherit}a.list-group-item.active .list-group-item-text{color:#e6f4fc}.panel{padding:15px;margin-bottom:20px;background-color:#fff;border:1px solid #ddd;border-radius:4px;-webkit-box-shadow:0 1px 1px rgba(0,0,0,0.05);box-shadow:0 1px 1px rgba(0,0,0,0.05)}

.baddge{
padding:3px 7px;
font-size:12px;
font-weight:bold;
color:#fff;
}

</style>