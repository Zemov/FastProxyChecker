﻿<?php
    $sql = "SELECT * FROM `orders` WHERE paid = '1' ORDER BY id DESC LIMIT $pplimit";
    $query = mysql_query($sql);

    if(!mysql_num_rows($query)) 
        echo "У нас ещё не кто не покупал";
    else
    {
        while($row = mysql_fetch_assoc($query))
        {  
            echo '<div class="coast rpsn">';
            echo $row['price'];
            echo $row['fund'];
            echo '<i>руб.</i></div><div class="title"><b>';
            echo $row['name'];
            echo '</b></div><br><div style="right: initial;" class="coast rpsn">';
            echo $row['price'];
	    echo '</div><br>';
        }
      }
?>  