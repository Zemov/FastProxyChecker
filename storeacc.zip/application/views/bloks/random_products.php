﻿<?php
$db_query = mysql_query("SELECT * FROM goods ORDER BY rand() LIMIT 1");
$db_data = mysql_fetch_assoc($db_query);
?>
									
<div class="box-content">
										<div class="box-product">
										<ul>
																						<li class="first-in-line">
												<div class="image">
													<a href="/product/<?php echo $db_data['id']; ?>"><img id="img_57" src="<?php echo $db_data['iconurl']; ?>" width="120" alt="<?php echo $db_data['name']; ?>"></a>
												</div>
												<div class="inner">
											 
													<div class="f-left">
														<center><span class="name"><a href="/product/<?php echo $db_data['id']; ?>" style="color:##7F7F7F; font-size: 11px;"><?php echo $db_data['name']; ?></a></span></center>
														<div class="price">
														<center><span class="price-new"><?php echo $db_data['price_rub']*100 /100; ?> RUB</span></center>
														</div>
														
													</div>
													<div class="clear"></div><br>
													<div class="cart" style="text-align: center;">
														<a href="/product/<?php echo $db_data['id']; ?>"  class="button"><span>Купить</span></a>
													</div>
													<div class="clear"></div>
												</div>
											</li>
																					</ul>
										</div>
									</div>

