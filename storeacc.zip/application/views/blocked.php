<div class="panel">
  <div class="panel-heading">
    <h3 class="panel-title">Доступ на сайт заблокирован</h3>
  </div>
  <div class="panel-body">
		Ваш ip  внесён в черный список
 </div>
</div>