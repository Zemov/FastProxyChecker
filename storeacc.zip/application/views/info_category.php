<HTML>
  <HEAD>
    <META HTTP-EQUIV="REFRESH" CONTENT="0; URL=http://avatar.dyrinda.ru/">
  </HEAD>
  <BODY>
  </BODY>
</HTML>