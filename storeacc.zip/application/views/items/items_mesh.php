﻿<table class="table table-bordered">
	<thead>
	</thead>
	<tbody>
		
<? if(count($items)): foreach($items as $item): ?>
<div rel='<? echo $item->id; ?>' style="height:260px;" class="macpay-snapshot" title="<? echo $item->name; ?>">
			<div class="macpay-snapprodnamehldr" style="width:155px;"  data-target="#myModal_<? echo $item->id;?>">
				<center>
<?php if(1 == config_item('vptsite')) { include "at_page.php";}
if(2 == config_item('vptsite')) { include "at_okno.php";} ?>
						<? echo empty($item->iconurl) ? '' : '<img style="max-width:155px;max-height: 155px;cursor:pointer;" src="'.$item->iconurl.'" />'; ?>
					</a>
				</center>
				<br>
			</div>
			<span class='min_count' style='display:none;' ><?php echo $item->min_order; ?></span>
				   		
			<center style="padding-bottom: 10px;min-height: 40px;"><div><? echo mb_substr($item->name, '0', '30'); ?></div></center>
		    <center style=" padding-bottom: 15px; color: #2900FF; display:none;">Осталось:<span class='max_count'><? echo $item->count; ?></span></center>
			<div>
				<div style="padding-bottom: 10px;font-size: 10px;">
				<input type="text" class="form-control input-micro" id="number-of-items-<? echo $item->id;?>" style="width:30px; height:20px;display:none;padding:0;" value="<? echo $item->min_order;?>">
				<span class="macpay-snapprice price"><? echo round($item->price_rub*100)/100;?></span>
				<span class="macpay-snapcurrency">RUB</span>
				<a class="macpay-buyButton" data-toggle="modal" data-target="#setWayForMoney" style="display:inline;cursor:pointer;" onclick="BuyButtonClick(<? echo $item->id;?>)">Купить</a>
			</div>
		</div>
					</div>
<? endforeach; ?>
<? else: ?>
<div class="">
Товаров пока нет...Приходите позже!
</div>
<? endif; ?>
	</tbody>
</table>

<style>
.macpay-snapshot {
background: #fff;
border: 1px solid #000000;
}

.category-info {
display: none;
}

.container {
margin-top: -14px;
margin-left: 27px;
}

</style>