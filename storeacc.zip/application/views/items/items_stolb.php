﻿<table class="table table-bordered">
	<thead>
	</thead>
	<tbody>
	<? if(count($items)): foreach($items as $item): ?>	
 <div class="item-loop">

        <div class="poster">

            <? echo empty($item->iconurl) ? '' : '<img style="max-width:128px;max-height: 60px;cursor:pointer;" src="'.$item->iconurl.'" />'; ?>
<?php if(1 == config_item('vptsite')) { include "at_page.php";}
if(2 == config_item('vptsite')) { include "at_okno.php";} ?>
            <span>Подробнее</span>

        </div>

        <div class="title">
            <font color=black><? echo $item->name; ?></font>

        </div>

            <div class="coast">

	<img style='margin-left:5px; ;max-height: 40px;' src="<? echo config_item('buypng'); ?>" data-toggle="modal" data-target="#setWayForMoney" style="display:inline;cursor:pointer;" onclick="BuyButtonClick(<? echo $item->id;?>)">
</div>
      <div class="coast">
 <span><? echo round($item->price_rub*100)/100;?><i>руб.</i></span>
</div>    

<div class="coast">
<span><? echo $item->count; ?><i>шт.</i></span>
</div>
 </div>   

<? endforeach; ?>
<? else: ?>
<div class="">
Товаров пока нет...Приходите позже!
</div>
<? endif; ?>
	</tbody>
</table>