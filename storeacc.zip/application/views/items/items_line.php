﻿<table class="table table-bordered">
	<thead>
	</thead>
	<tbody>
	<? if(count($items)): foreach($items as $item): ?>	
 <div class="media">		<a href="<?php echo base_url("product/".$item->id); ?>">			<div class="shortleft"></div>			<div class="shortposter">				<div class="shortimg">					<div class="shortlang">						US					</div>					<img src="<? echo $item->iconurl; ?>">					<div class="salesh">						Купить					</div>				</div>			</div>		</a>				<div class="media-body">			<div class="media-info">				<h3 class="media-heading"><a href="<?php echo base_url("product/".$item->id); ?>"><? echo $item->name; ?></a></h3>				<ul class="fold">					<li class="active"><i class="fa fa-folder-open"></i> <?php foreach($categories as $category): ?>						<li><? echo anchor('category/' . $category->id, $category->title); ?></li>					<?php endforeach; ?></li>					<li><i class="fa fa-cart-plus"></i> Товара в наличии: <? echo $item->count; ?> шт.</li>					<li><i class="fa fa-cart-plus"></i> Продан: 0 раз(а)</li>				</ul>			</div>			<div class="media-sale">				<div class="valinfo pull-right">					<div class="val">						<i class="fa fa-rub"></i>					</div>					<? echo round($item->price_rub*100)/100;?>			</div>							</div>		</div>	</div>  

<? endforeach; ?>
<? else: ?>
<div class="">
Товаров пока нет...Приходите позже!
</div>
<? endif; ?>
	</tbody>
</table>