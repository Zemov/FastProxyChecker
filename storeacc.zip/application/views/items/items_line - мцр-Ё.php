﻿</div>
<table class="table table-bordered">	
	<thead>

		<th><center>Товар</center></th>
		<th><center>Кол-во</center></th>
		<th><center>Цена</center></th>
                <th><center>Купить</center></th>
	</thead>
	<tbody>


<? if(count($items)): foreach($items as $item): ?>
		<tr>
			
<td>

<?php if(1 == config_item('vptsite')) { include "at_page.php";}
if(2 == config_item('vptsite')) { include "at_okno.php";} ?>

<? echo empty($item->iconurl) ? '' : '<img class="iconurl" src="'.$item->iconurl.'" />'; ?><? echo $item->name; ?><i class="pull-right glyphicon glyphicon-info-sign"></i></td>

			<td data-id="<? echo $item->count == "Файл" ? "" : $item->id ;?>"><center><span class="macpay-snapprice price"><? echo $item->count; ?></span></td>
			<input type="text" class="form-control input-micro" id="number-of-items-<? echo $item->id;?>" style="width:30px; height:20px;display:none;padding:0;" value="<? echo $item->min_order;?>">
			<td><center><span class="macpay-snapprice price"><? echo round($item->price_rub*100)/100;?> Ᵽ</span></td>


			<td style="width: 84px; padding-top: 19px;"><a class="macpay-buyButton" data-toggle="modal" data-target="#setWayForMoney" style="display:inline;cursor:pointer;margin-left: 1px;" onclick="BuyButtonClick(<? echo $item->id;?>)">Купить</a></td>


		</tr>
<? endforeach; ?>
<? else: ?>
	<tr>
<table class="clear">	
<div class="">
Товаров пока нет...Приходите позже!
</div>
	</tr>
<? endif; ?>
	</tbody>
</table>
  <style>
			.wowlight2 {color:#FF00FF;}
   TABLE {
    background: #FFFFFF; 
    color: #000000; 
    margin-top: -20px;
   }
   TD {
    background: #FFFFFF; 
   }
  </style>