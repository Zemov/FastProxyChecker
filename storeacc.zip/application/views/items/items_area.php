﻿<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="http://primearea.ru/shopsite/v1.1/index.php?id=<? echo config_item('primearea'); ?>" charset="utf-8"></script>
<link media="screen" href="http://primearea.ru/shopsite/v1.1/my_site_style.css" type="text/css" rel="stylesheet" />
</head>
<body> 
<div id="primearea_main">
    <div style="text-align:center;"><img src="http://primearea.ru/shopsite/v1.1/img/preloader.gif" alt="Загрузка..."></div>
    <noscript>Ваш браузер не поддерживает JavaScript.</noscript>
</div>
<div id="primearea_category">
    <div style="text-align:center;"><img src="http://primearea.ru/shopsite/v1.1/img/preloader.gif" alt="Загрузка..."></div>
    <noscript>Ваш браузер не поддерживает JavaScript.</noscript>
</div>
</body>

<style>
.Formlist {
height: 37px;
border-radius: 0px;
}

.nameFormlist {
height: 37px;
right: 0px;
border-radius: 0px 0 0 0px;
padding: 8px 5px;
}

.priceFormlist {
height: 37px;
border-radius: 0 0px 0px 0;
padding: 8px 5px;
}

.category_el {
height: 37px;
padding: 8px 5px;
}

#primearea_main {
margin-top: -28px;
}

.category-info {
padding: 9px 0px 0px 8px;
}

.FormPage .buyformdivFormPage {
height: 62px;
}

</style>
