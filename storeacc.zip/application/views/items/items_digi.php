﻿<script type="text/javascript" src="http://www.digiseller.ru/shop/digiseller-api.js.asp?seller_id=<? echo config_item('digiid'); ?>" charset="utf-8"></script>
<div id="digiseller-main" class="digiseller-main"><div style="text-align:center;"><img src="http://www.digiseller.ru/shop/img/preloader.gif" alt="Загрузка..." /></div><noscript>Ваш браузер не поддерживает JavaScript.</noscript></div>
<style>
.digiseller-productList.digiseller-homepage {
margin-top: 0px;
}

.digiseller-snapshot {
margin-top: -3px;
width: 156px;
}

.digiseller-snapshot img {
width: 150px;
}

.digiseller-snapshot div {
width: 152px;
}

.digiseller-snapshot span.digiseller-snapname {
font-size: 9px;
}

.digiseller-calc a.digiseller-buybutton {
height: 30px;
width: 91px;
}

</style>