﻿<? echo $modals; ?>
<style>
.paytable > tbody > tr > td{border: 1px solid #797360;padding: 5px 10px;vertical-align: middle;}
.paytable{color: #000;}
</style>
  <div class="modal fade" id="paymodal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title">Оплата</h4>
        </div>
        <div class="modal-body">
        <table class="paytable">
		  <tr>
			  <td>Товар:</td>
			  <td class="payitem">...</td>
		  </tr>
		  <tr>
			  <td>Кол-во:</td>
			  <td class="paycount">...</td>
		  </tr>
		  <tr>
			  <td>К оплате:</td>
			  <td class="payprice">...</td>
		  </tr>
		  <tr>
			  <td>Ваша скидка:</td>
			  <td class="paypercentage">...</td>
		  </tr>
		  <tr>
			  <td>Кошелек для платежа:</td>
			  <td id="copyfund" class="payfund">...</td>
		  </tr>
		  <tr>
			  <td>Примечание к платежу:</td>
			  <td id="copybill" class="paybill">...</td>
		  </tr>
		</table>
        </div>
		<div class="alert alert-danger">
			<strong>Обязательно</strong> переводите деньги именно с таким примечанием!
		</div>
        <div class="payfoot modal-footer">
          <button type="button" onclick="" data-loading-text="Проверяем..." class="checkpaybtn btn btn-primary">Проверить</button>
        </div>
      </div>
    </div>
  </div>
<table class="table table-bordered">
	<thead>
	</thead>
	<tbody>
	<div class="category-info">	
	<div style="display: none;" class="breadcrumb"><center><b><? echo config_item('site_kvbloga'); ?></b></center></div>
	

<?php if(0 == config_item('site_tptovar')) { include "items/items_line.php"; } ?>
<?php if(1 == config_item('site_tptovar')) { include "items/items_mesh.php"; } ?>
<?php if(2 == config_item('site_tptovar')) { include "items/items_area.php"; } ?>
<?php if(3 == config_item('site_tptovar')) { include "items/items_digi.php"; } ?>

<? if(count($items)) : ?>
<div class="panel" style="display:none;">
	<div class="row">
	  <div class="col-lg-3">
		<label class="control-label" for="item">Товар:</label>
		<select class="form-controler input-small" name="item" id="item-selected">
		<? foreach($items as $item): ?>
			<option value="<? echo $item->id; ?>" data-id="<? echo $item->id; ?>" data-min_order="<? echo $item->min_order; ?>"><? echo $item->name; ?></option>
		<? endforeach; ?>
		</select>
	  </div>
	  <div class="col-lg-2">
		<label class="control-label" for="funds">Валюта:</label>
		<select class="form-controler input-small"  name="funds" id="fundsSelect">
			<? foreach($funds as $fund): ?>
			<option value="<? echo $fund['fundid']; ?>" data-fund="<? echo $fund['fundname']; ?>"><? echo $fund['fundname']; ?></option>
			<? endforeach; ?>
		</select>
	  </div>
	  <div class="col-lg-3">
		<label class="control-label" for="email">E-mail:</label>
		<input type="email"  id="row-box-email" class="form-controler input-small" name="email">
	  </div>
	  <div class="col-lg-2">
		<button onclick="sendData();" type="button" class="btn btnbuy btn-primary btn-lg btn-block">Оплатить</button>
	  </div>
	</div>
</div>
<? endif; ?>
	  <div class="modal fade" id="setWayForMoney">
		<div style="margin-top: 30px;margin-centre: 10px;width:350px;" class="modal-dialog">
		  <div class="modal-content">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title">Выберите способ оплаты</h4>
			</div>
			<div class="modal-body"></a>
		<input type="email" placeholder="кол-во" class="form-control input-small" name="count"  id="end-number"><br>
				<input type="email" class="form-control input-small" id="alert-box-email" placeholder="Ваш Email" onInput="checkEmail();"><br>
	  </div>
				<center><?php
if(1 == config_item('site_pwebmoney')){
echo '<button onclick="setWayForMoney(1);setEmail();" id="setEmailButton" data-dismiss="modal" aria-hidden="true" data-toggle="modal" type="button" class="btn btnbuy btn-white btn-lg btn-block" style="padding: 5px;margin-left: 0px;margin-top: 1px;"><img src="/img/wm.png" style="height:45px;"></button>';
}
else{
}
?>

<?php
if(1 == config_item('site_pqiwi')){
echo '<button onclick="setWayForMoney(4);setEmail();" id="setEmailButton" data-dismiss="modal" aria-hidden="true" data-toggle="modal" type="button" class="btn btnbuy btn-white btn-lg btn-block" style="padding: 5px;margin-left: 0px;margin-top: 1px;"><img src="/img/qw.png" style="height:45px;"></button>';
}
else{
}
?>

<?php
if(1 == config_item('site_pyandex')){
echo '<button onclick="setWayForMoney(3);setEmail();" id="setEmailButton" data-dismiss="modal" aria-hidden="true" data-toggle="modal" type="button" class="btn btnbuy btn-white btn-lg btn-block" style="padding: 5px;margin-left: 0px;margin-top: 1px;"><img src="/img/ya.png" style="height:45px;"></button>';

}
else{
}
?>


</center>
				<center><div style="margin-top:10px;">
					<input type="checkbox" id="agreeLicense" onChange="checkAgreeLicense();">
					<span style='color:black;font-size: 15px;font-family: "Open Sans","Helvetica Neue",Helvetica,Arial,sans-serif;'>Принимаю условия </span>      <a style='font-size: 15px;font-family: "Open Sans","Helvetica Neue",Helvetica,Arial,sans-serif;' data-toggle="modal" data-target="#agreement"class="btn btnbuy btn-primary btn-lg btn-block">Введите купон (если есть)</a>

				</div></center>
			</div>
		  </div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	  </div><!-- /.modal -->
	  <div class="modal fade" id="agreement">
		<div style="margin-top: 30px;margin-centre: 10px;width:350px;" class="modal-dialog">
		  <div class="modal-content">
			<div class="modal-header">
			  <button type="button" class="close" style="opacity:1;font-size:28px;" data-dismiss="modal" aria-hidden="true"></button>
			  	<input type="cupon" id="cupon" class="form-control input-small" name="cupon" placeholder="Вставьте купон" style="width:280px;margin-centre:5px;">

			</div>
			<div class="">
               <? echo config_item('sogl'); ?>
			</div>
		  </div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	  </div>


	  <style>
.btn-block {
    display: block;
    width: 100%;
    padding-right: 0px;
    padding-left: 0px;
}

.btn-primary {
    color: #FFF;
    background-color: #2FA4E7;
    border-color: #2FA4E7;
}

.btn-primary:hover, .btn-primary:focus, .btn-primary:active, .btn-primary.active, .open .dropdown-toggle.btn-primary {
 color: #FFF;
    background-color: #2FA4E7;
    border-color: #2FA4E7;
	}

	.modal-header {
    min-height: 16.4286px;
    padding: 15px;
    border-bottom: 1px solid rgba(255, 255, 255, 1);
	
	
	
	  </style>
	  
	  
	  <style>
	  
	  .modal-body {
    border: 1px solid rgba(233, 233, 233, 1);
    overflow: hidden;
}

.modal-content {
    position: relative;
    background-color: rgba(245, 245, 245, 1);
    border: 1px solid rgba(0, 0, 0, 0.2);
    border-radius: 0px;
    outline: 0px none;
    box-shadow: 0px 3px 9px rgba(0, 0, 0, 0.5);
    background-clip: padding-box;
}
	  
	  </style>