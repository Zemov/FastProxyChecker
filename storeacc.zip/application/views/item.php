﻿<? echo $modals; ?>
<style>
.paytable > tbody > tr > td{border: 1px solid #797360;padding: 5px 10px;vertical-align: middle;}
.paytable{color: #000;}
</style>
  <div class="modal fade" id="paymodal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
        <div class="modal-body">
        <table style="width: 518px; margin-right: 25px;" class="paytable">
		  <tr>
			  <td style="width: 258px;border: 2px solid #000000;">Товар:</td>
			  <td style="border: 2px solid #000000;" class="payitem">...</td>
		  </tr>
		  <tr>
			  <td style="width: 258px;border: 2px solid #000000;">Кол-во:</td>
			  <td style="border: 2px solid #000000;" class="paycount">...</td>
		  </tr>
		  <tr>
			  <td style="width: 258px;border: 2px solid #000000;">К оплате:</td>
			  <td style="border: 2px solid #000000;" class="payprice">...</td>
		  </tr>
		  <tr>
			  <td style="width: 258px;border: 2px solid #000000;">Ваша скидка:</td>
			  <td style="border: 2px solid #000000;" class="paypercentage">...</td>
		  </tr>
		  <tr>
			  <td style="width: 258px;border: 2px solid #000000;">Кошелек для платежа:</td>
			  <td style="border: 2px solid #000000;" id="copyfund" class="payfund">...</td>
		  </tr>
		  <tr>
			  <td style="width: 258px;border: 2px solid #000000;">Примечание к платежу:</td>
			  <td style="border: 2px solid #000000;"id="copybill" class="paybill">...</td>
		  </tr>
		</table>
        </div>
		<div style="padding-left: 72px; padding-right: 72px;" class="alert alert-danger">
			<strong>Обязательно</strong> переводите деньги именно с таким примечанием!
		</div>
        <div class="payfoot modal-footer">
          <button type="button" onclick="" data-loading-text="Проверяем..." class="checkpaybtn btn btn-primary">Проверить</button>
        </div>
      </div>
    </div>
  </div>
<table class="table table-bordered">
	<thead>
	</thead>
	<tbody>
	
<? if(count($items)): foreach($items as $item): ?><div class="container">			<div class="col-md-12 fullt">		<div class="ftitle"> 			<? echo $item->name; ?>		</div>	</div>	<div class="clearfix"></div>		<div class="row">		<div class="fullstory">			<div class="col-md-5 col-sm-5">				<div class="fullimg">					<img src="<? echo $item->iconurl; ?>" class="img-responsive center-block" style="    border-radius: 10px;">				</div>			</div>			<div class="col-md-5 col-md-5 fullinfo">							<ul>					<li><i class="fa fa-folder-open"></i> Категория: <?php foreach($categories as $category): ?>						<li><? echo anchor('category/' . $category->id, $category->title); ?></li>					<?php endforeach; ?></li>					<li><i class="fa fa-cart-arrow-down"></i> Количество продаж: 0 раз(а)</li>					<li><i class="fa fa-map-marker"></i> Регион: </li>					<li><i class="fa fa-check-square"></i> В наличии: <? echo $item->count; ?> шт</li>				</ul>			</div>			<div class="col-md-2 col-md-2">				<div class="btn btn-warning btn-block"><? echo round($item->price_rub*100)/100;?> руб.</div>				<div class="sale">					<button class="btn btn-green btn-block" data-toggle="modal" data-target="#setWayForMoney">						<i class="fa fa-shopping-cart"></i> Купить					</button>														</div>			</div>				</div>		<div class="clearfix"></div>				<div class="way">			<h3>Почему именно мы?</h3><h3>			<div class="dashed center-block"></div>		</h3></div>		<div class="clearfix"></div>		<div class="waywe">			<div class="punct">				<span class="num">1</span> Моментально доставим товар на E-mail				<div class="clearfix"></div>			</div>			<div class="punct">				<span class="num">2</span> Окажем квалифицированную тех. поддержку				<div class="clearfix"></div>			</div>			<div class="punct">				<span class="num">3</span> Обменяем товар (в случае неисправности)				<div class="clearfix"></div>			</div>		</div>	</div>		<div class="clearfix"></div>	<div class="card">		<ul class="nav nav-tabs" role="tablist">			<li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab" aria-expanded="true">Описание</a></li>			<li role="presentation" class=""><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="false">Дополнительная информация</a></li>			<li role="presentation" class=""><a href="#active" aria-controls="messages" role="tab" data-toggle="tab" aria-expanded="false">Активация</a></li>			<li role="presentation" class=""><a href="#rules" aria-controls="settings" role="tab" data-toggle="tab" aria-expanded="false">Правила</a></li>			<li role="presentation" class=""><a href="#otziv" aria-controls="settings" role="tab" data-toggle="tab" aria-expanded="false">Отзывы</a></li>		</ul>		<div class="tab-content">			<div role="tabpanel" class="tab-pane active" id="home"><p><? echo $item->descr; ?></p><br></p><p><span class="snum">1</span> В качестве бонуса на аккаунте могут быть другие игры.</p><p><span class="snum">2</span> Перед установкой обязательно деактивируйте аккаунт, как это сделать? Ответ: смотреть тут - <a href="http://storeacc.ru/page/deactivation" target="_blank">клик</a>.</p><p><span class="snum">3</span> Гарантия на аккаунт 30 мин.(подразумевается, что вы просто поставите на загрузку)</p><p><span class="snum">4</span> Прежде чем купить, ознакомьтесь с инструкцией во вкладке <a href="#active" aria-controls="messages" role="tab" data-toggle="tab" aria-expanded="true">"Активация"</a> установки игр на вашу консоль. Заранее обновите консоль, если это потребуется. </p><hr><p>После покупки оставьте пожалуйста <a href="http://storeacc.ru/page/reviews" target="_blank">тут</a> и <a href="http://zadroteam.ru/storeacc-ru/" target="_blank">тут</a> отзыв(в качестве бонуса за отзыв дам рандом аккаунт ps3/ps4)</p><p>За рандом аккаунтом обращаться в skype(<a href="skype:repin.11?add">тык</a>)</p><br><div class="alert alert-warning"> <strong><i class="fa fa-exclamation-triangle"></i></strong> Важная информация: <hr> <p>После покупки сразу же проверяйте аккаунт на работоспособность!!! Гарантия на все аккаунты - 30 минут!</p>  <p>Eсли на консоли используется более 14 аккаунтов, то Sony банят id консоли на 30 дней.</p> <p>Поэтому, если вы набрали количество активированных на вашей приставке аккаунтов, равное 14 и вы хотите добавить еще аккаунт, то следует сначала деактивировать один из аккаунтов, а затем уже добавлять новые.</p> <p>ВАЖНО! Если при активации Вашей консоли возникают какие-либо проблемы или вам непонятен порядок действий, Вы можете обратиться к продавцу посредством переписки и Мы Вам поможем.</p></div></div>			<div role="tabpanel" class="tab-pane" id="profile"><div class="dopinfo">			<h2><i class="fa fa-book"></i> Правила использования: Купивший этот товар автоматически их принимает.</h2>			<hr><p><i class="fa fa-dot-circle-o"></i> Аккаунты вида mail:pass для доступа в PSN</p><p><i class="fa fa-dot-circle-o"></i> Играть на купленном аккаунте запрещается.</p><p><i class="fa fa-dot-circle-o"></i> Играть строго со своего пользователя.</p><p><i class="fa fa-dot-circle-o"></i> Доступа к почте нет!</p><p><i class="fa fa-dot-circle-o"></i> Пароль от аккаунта менять запрещено.</p><p><i class="fa fa-dot-circle-o"></i> Все гарантии на момент продажи в течении 30 мин на проверку работоспособности.</p><p><i class="fa fa-dot-circle-o"></i> Замена аккаунта(в случае не работоспособности) в течении 24х часов.</p></div><hr><div class="alert alert-warning"><i class="fa fa-exclamation-triangle"></i> БУДЬТЕ ВНИМАТЕЛЬНЫ:<hr><p><i class="fa fa-long-arrow-right"></i> Если вы не имеете представления как пользоваться аккаунтом, пожалуйста, воздержитесь от покупки.</p><p><i class="fa fa-long-arrow-right"></i> Настоятельно рекомендуем поискать в интернете информацию по использованию аккаунта PSN.</p><p><i class="fa fa-long-arrow-right"></i> В случае порчи аккаунта, к которому привели не соблюдения условий - возврата средств и обмена аккаунта производиться НЕ БУДЕТ!</p></div></div>			<div role="tabpanel" class="tab-pane" id="active"><p>•УСТАНОВКА АККАУНТА PLAYSTATION VITA•</p><p></p><p>1. Если у вас уже имеется учетная запись чтобы не потерять существующие данные, их нужно сохранить. Производится эта операция очень просто: подключаете свою PS Vita к PC или PS3-PS4 и включаете ContentManager (Помошник по управлению данными PlayStation). </p><p></p><p>Версию для PC можно скачать тут (http://cma.dl.playstation.net/cma/win/ru/index.html)</p><p></p><p>Резервное копирование — одна из основных функций программы, полностью переносящая на жесткий диск содержимое карты памяти. Позже восстановить резервную копию можно одним нажатием кнопки.</p><p></p><p>2. Следующим вашим действием будет восстановление заводских настроек. Это приведет к возвращению консоли в тот вид, в котором она была при покупке.</p><p></p><p>Обратите внимание, что для регистрации Виты под другим аккаунтом необходимо отменить активацию старого. </p><p></p><p>Сделать это можно:</p><p></p><p>а) через настройки — настройки PSN.</p><p></p><p>б) через восстановление системы (форматирование).</p><p></p><p>3. Создаете пользователя, вносите данные, далее идете в PS Store и ставите качать игры.</p><p></p><p>4. Восстановить первую (свою) учетную запись можно так же через ПК или PS3-PS4 с помощью ContentManager.</p><p></p></div>			<div role="tabpanel" class="tab-pane" id="rules">...</div>			<div role="tabpanel" class="tab-pane" id="otziv"><!-- Put this script tag to the <head> of your page --><script type="text/javascript" src="//vk.com/js/api/openapi.js?117"></script><script type="text/javascript">   VK.init({apiId: 5010883, onlyWidgets: true});</script><!-- Put this div tag to the place, where the Comments block will be --><div id="vk_comments" style="height: 148px; width: 940px; background: none;"><iframe name="fXD14b5f" frameborder="0" src="http://vk.com/widget_comments.php?app=5010883&amp;width=940px&amp;_ver=1&amp;limit=5&amp;height=0&amp;mini=auto&amp;norealtime=0&amp;page=0&amp;status_publish=1&amp;attach=*&amp;url=http%3A%2F%2Fstoreacc.ru%2Fgoods%2Finfo%2F385&amp;title=%D0%90%D0%BA%D0%BA%D0%B0%D1%83%D0%BD%D1%82%D1%8B%20PSN%20-%20%D0%BA%D1%83%D0%BF%D0%B8%D1%82%D1%8C%20%D0%B0%D0%BA%D0%BA%D0%B0%D1%83%D0%BD%D1%82%20%D0%B4%D0%BB%D1%8F%20PS3%2C%20PS4%2C%20Vita&amp;description=%D0%9C%D0%B0%D0%B3%D0%B0%D0%B7%D0%B8%D0%BD%20%D1%86%D0%B8%D1%84%D1%80%D0%BE%D0%B2%D1%8B%D1%85%20%D1%82%D0%BE%D0%B2%D0%B0%D1%80%D0%BE%D0%B2%2C%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%BE%D0%B9%20%D0%B2%D1%8B%D0%B1%D0%BE%D1%80%20%D0%B0%D0%BA%D0%BA%D0%B0%D1%83%D0%BD%D1%82%D0%BE%D0%B2%20psn%2C%20ps4%2C%20ps3%20%D0%BF%D0%BE%20%D0%BF%D1%80%D0%B8%D0%B2%D0%BB%D0%B5%D0%BA%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D1%8B%D0%BC%20%D1%86%D0%B5%D0%BD%D0%B0%D0%BC.%20%D0%A1%D0%BA%D0%B8%D0%B4%D0%BA%D0%B8%20%D0%BF%D0%BE%D1%81%D1%82%D0%BE%D1%8F%D0%BD%D0%BD%D1%8B%D0%BC%20%D0%BF%D0%BE%D0%BA%D1%83%D0%BF%D0%B0%D1%82%D0%B5%D0%BB%D1%8F%D0%BC.&amp;image=&amp;referrer=http%3A%2F%2Fstoreacc.ru%2F&amp;15264c7faf2" width="940" height="133" scrolling="no" id="vkwidget1" style="overflow: hidden; height: 148px;"></iframe></div><script type="text/javascript">VK.Widgets.Comments("vk_comments", {limit: 5, width: "940", attach: "*"});</script></div>		</div>	</div>								 <div class="skrin magnific">												</div>					</div>
		
		<? endforeach; ?>
<? else: ?>
	<tr>
		<td colspan="3">Товар не найден...Приходите позже!</td>
	</tr>
<? endif; ?>
	</tbody>
</table>
<? if(count($items)) : ?>
<div class="panel" style="display:none;">
	<div class="row">
	  <div class="col-lg-3">
		<label class="control-label" for="item">Товар:</label>
		<select class="form-controler input-small" name="item" id="item-selected">
		<? foreach($items as $item): ?>
			<option value="<? echo $item->id; ?>" data-id="<? echo $item->id; ?>" data-min_order="<? echo $item->min_order; ?>"><? echo $item->name; ?></option>
		<? endforeach; ?>
		</select>
	  </div>
	  <div class="col-lg-2">
		<label class="control-label" for="funds">Валюта:</label>
		<select class="form-controler input-small"  name="funds" id="fundsSelect">
			<? foreach($funds as $fund): ?>
			<option value="<? echo $fund['fundid']; ?>" data-fund="<? echo $fund['fundname']; ?>"><? echo $fund['fundname']; ?></option>
			<? endforeach; ?>
		</select>
	  </div>
	  <div class="col-lg-3">
		<label class="control-label" for="email">E-mail:</label>
		<input type="email"  id="row-box-email" class="form-controler input-small" name="email">
	  </div>
	  <div class="col-lg-2">
		<button onclick="sendData();" type="button" class="btn btnbuy btn-primary btn-lg btn-block">Оплатить</button>
	  </div>
	</div>
</div>
<? endif; ?>
	  <div class="modal fade" id="setWayForMoney">
		<div style="margin-top: 30px;margin-centre: 10px;width:600px;" class="modal-dialog">
		  <div class="modal-content">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 style="display: none;padding-left: 200px; padding-right: 200px;" class="modal-title">Выберите способ оплаты</h4>
			</div>
			<div class="modal-body"></a>
		<input type="email" placeholder="кол-во" class="form-control input-small" name="count"  id="end-number"><br>
				<input type="email" class="form-control input-small" id="alert-box-email" placeholder="Ваш Email" onInput="checkEmail();"><br>
				<input type="cupon" id="cupon" class="form-control input-small" name="cupon" placeholder="Вставьте купон (если есть)">
	  </div>
				<center><?php
if(1 == config_item('site_pwebmoney')){
echo '<button onclick="setWayForMoney(1);setEmail();" id="setEmailButton" data-dismiss="modal" aria-hidden="true" data-toggle="modal" type="button" class="btn btnbuy btn-white btn-lg btn-block" style="padding: 5px;margin-left: 0px;margin-top: 1px;"><img src="/img/wm.png" style="height:45px;"></button>';
}
else{
}
?>

<?php
if(1 == config_item('site_pqiwi')){
echo '<button onclick="setWayForMoney(4);setEmail();" id="setEmailButton" data-dismiss="modal" aria-hidden="true" data-toggle="modal" type="button" class="btn btnbuy btn-white btn-lg btn-block" style="padding: 5px;margin-left: 0px;margin-top: 1px;"><img src="/img/qw.png" style="height:45px;"></button>';
}
else{
}
?>

<?php
if(1 == config_item('site_pyandex')){
echo '<button onclick="setWayForMoney(3);setEmail();" id="setEmailButton" data-dismiss="modal" aria-hidden="true" data-toggle="modal" type="button" class="btn btnbuy btn-white btn-lg btn-block" style="padding: 5px;margin-left: 0px;margin-top: 1px;"><img src="/img/ya.png" style="height:45px;"></button>';

}
else{
}
?>
</center>


				</div>
			</div>
		  </div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	  </div><!-- /.modal -->
	  <div class="modal fade" id="agreement">
		<div style="margin-top: 30px;margin-centre: 10px;width:350px;" class="modal-dialog">
		  <div class="modal-content">
			<div class="modal-header">
			  <button type="button" class="close" style="opacity:1;font-size:28px;" data-dismiss="modal" aria-hidden="true"></button>
			  	<input type="cupon" id="cupon" class="form-control input-small" name="cupon" placeholder="Вставьте купон" style="width:280px;margin-centre:5px;">

			</div>
			<div class="">
               <? echo config_item('sogl'); ?>
			</div>
		  </div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	  </div>


	 <style>
	  .product-info {
margin-top: -11px;
background-color: rgb(255, 255, 255);
padding: 15px;
border-radius: 5px;
box-shadow: rgba(0, 0, 0, 0.0901961);
}

#content .box .box-content {
margin-top: -100;
background: none;
}


.modal {
overflow-y: auto;
}



</style>


  <style>
.btn-block {
    display: block;
    width: 100%;
    padding-right: 0px;
    padding-left: 0px;
    height: 56px;
}

.btn-primary {
    color: #FFF;
    background-color: #2FA4E7;
    border-color: #2FA4E7;
}

.btn-primary:hover, .btn-primary:focus, .btn-primary:active, .btn-primary.active, .open .dropdown-toggle.btn-primary {
 color: #FFF;
    background-color: #2FA4E7;
    border-color: #2FA4E7;
	}

	.modal-header {
    min-height: 16.4286px;
    padding: 15px;
    border-bottom: 1px solid rgba(255, 255, 255, 1);
	
	  </style>
	  
	  
	  <style>
	  
	  .modal-body {
    border: 1px solid rgba(233, 233, 233, 1);
    overflow: hidden;
}

.modal-content {
    position: relative;
    background-color: rgba(245, 245, 245, 1);
    border: 1px solid rgba(0, 0, 0, 0.2);
    border-radius: 0px;
    outline: 0px none;
    box-shadow: 0px 3px 9px rgba(0, 0, 0, 0.5);
    background-clip: padding-box;
}

#side-right {
display:none;
}

.modal-body {
border: 0px solid rgba(233, 233, 233, 1);
overflow: hidden;
}

.modal-header {
min-height: 16.4286px;
padding: 15px;
border-bottom: 0px solid rgba(255, 255, 255, 1);
}

  
	  </style>
	 