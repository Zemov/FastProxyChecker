﻿<? $this->load->view('admin/components/adm_head')?>
  <body>
<div class="wrap">
	<div id="header">
		<div style="margin-top: -8px;" id="top">
			<div class="left">
				<p><strong>Добро Пожаловать в Админ-Панель</strong> [<a href="/admin/user/logout">Выйти</a>]</p>
			</div>
		</div>
	</div>
	
	<div id="content">
		<div id="sidebar">
			<div class="box">
				<div class="h_title">&#8250; Контроль</div>
				<ul id="home">	
					<li class="b1"><a class="icon view_page" href="/admin/goods/" target="_blank">Главная Страница</a></li>
					<li class="b1"><a class="icon view_page" href="/" target="_blank">Открыть магазин</a></li>
					<li class="b2"><a class="icon report" href="/admin/goods">Товары</a></li>
                                                                      <li class="b2"><a class="icon report" href="/admin/kupon">Купоны</a></li>
                                        <li class="b1"><a class="icon category" href="/admin/categories">Категории</a></li>
					<li class="b2"><a class="icon add_page" href="/admin/goods/edit">Добавить товар</a></li>

                                        <li class="b1"><a class="icon users" href="/admin/orders">Заказы</a></li>
                                        <li class="b2"><a class="icon block_users" href="/admin/stat">Статистика</a></li>					<li class="b2"><a class="icon config" href="/admin/config">Настройки</a></li>
				</ul>
			</div>
			
			<div class="box">
				<div class="h_title">&#8250; Дизайн</div>
				<ul>
					<li class="b1"><a class="icon view_page" href="/admin/goods/" target="_blank">Главная Страница</a></li>
					<li class="b1"><a class="icon page" href="/admin/design">Управление дизайном</a></li>
					<li class="b2"><a class="icon category"  href="/admin/page/">Страницы</a></li>
					<li class="b1"><a class="icon add_page" href="/admin/page/edit">Добавить страницу</a></li>
				</ul>
			</div>
			<div class="box">
				<div class="h_title">&#8250; Пользователь</div>
				<ul>
					<li class="b1"><a class="icon view_page" href="/admin/goods/" target="_blank">Главная Страница</a></li>
					<li class="b1"><a class="icon users" href="/admin/security">Смена пароля</a></li>
                                        <li class="b1"><a class="icon block_users" href="/admin/security">Заблокированные IP</a></li>
                                        <li class="b1"><a class="icon add_page" href="/admin/security/edit">Заблокировать IP</a></li>
				</ul>
			</div>
			<div class="box">
				<div class="h_title">&#8250; Управление</div>
				<ul>
					<li class="b1"><a class="icon view_page" href="/admin/goods/" target="_blank">Главная Страница</a></li>
					<li class="b1"><a class="icon config" href="/admin/bloks">Управление блоками</a></li>
				</ul>
			</div>
		<div class="box">
				<div class="h_title">&#8250; В Разработке</div>
				<ul>
				</ul>
			</div>
		</div>
		<div id="main">

			<div class="clear"></div>
			
			<div class="full_w">
			<div class="<? echo $subview == 'admin/orders' ? 'col-lg-12' : 'col-lg-8';?>">
			<? empty($subview) ? "" : $this->load->view($subview)  ?>
			<? if($subview != 'admin/orders'): ?>
			</div>
		</div>
		<div class="clear"></div>
	</div>
			<? endif; ?>
<div id="footer">
		<div class="left">
			<p>Админ панель: <? echo $this->config->item('site_name'); ?></p>
		</div>
<div class="right">
			<p>Copyright © 2014</p>
		</div>
	</div>
</div>
<? $this->load->view('admin/components/adm_foot'); ?>

<style>
#sidebar .box .h_title {
background: url(/goodakk/b-nav.png) no-repeat 0 0;
cursor: pointer;
color: #fff;
font-size: 14px;
font-family: tahoma;
width: 151px;
height: 36px;
padding-left: 38px;
padding-top: 11px;
margin-left: -1px;
text-shadow: #5403FF 0px 1px 1px;
display: block;
}

#footer {
background: #F00;
border-top: 0px solid #404345;
color: #FFFFFF;
float: left;
margin: 0 auto;
font-weight: bold;
padding: 8px 20px;
text-shadow: #5403FF 0px 1px 1px;
width: 860px;
}

table th {
background: #F00;
color: #fff;
border-left: 1px solid #ffffff;
border-right: 1px solid #ffffff;
font-size: 11px;
font-weight: bold;
padding: 7px;
text-shadow: 0px 1px #5403FF;
}

.btn-primary {
color: #fff;
background-color: #F00;
border-color: #F00;
float: right!important;
margin-right: 15px;
}

</style>
	<style>
#sidebar {
height: 800px;
background-color: #f3f3f3;
margin: 0;
-webkit-border-bottom-left-radius: 6px;
-moz-border-radius-bottomleft: 6px;
border-bottom-left-radius: 0px;
-webkit-box-shadow: inset -3px 5px 10px 1px rgba(0,0,0,.03);
-moz-box-shadow: inset -3px 5px 10px 1px rgba(0,0,0,.03);
box-shadow: inset -3px 5px 10px 1px rgba(0,0,0,.03);
}

table {
font-size: 11px;
}

#header #nav {
padding-top: 0px;
}

</style>