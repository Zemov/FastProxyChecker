﻿
<!DOCTYPE html>
<html>
  <head>
    <title>Добро Пожаловать в Админ Панель</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="http://newshopeasy.newabuy.ru/assets/css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="http://newshopeasy.newabuy.ru/assets/css/bootstrap-glyphicons.css" rel="stylesheet" media="screen">
	<script src="http://code.jquery.com/jquery.js"></script>
	<script type="text/javascript" src="http://code.jquery.com/ui/1.10.0/jquery-ui.js"></script>
	<script type="text/javascript" src="http://newshopeasy.newabuy.ru/assets/js/tinymce/tinymce.min.js"></script>
	<script type="text/javascript" src="http://newshopeasy.newabuy.ru/assets/js/custom.js"></script>
	<script type="text/javascript">
	tinymce.init({
		selector: "textarea.tinymce",
		plugins: [
			"advlist autolink lists link image charmap print preview anchor",
			"searchreplace visualblocks code fullscreen",
			"insertdatetime media table contextmenu paste"
		],
		toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
	});
	</script>
	<script type="text/javascript">
	$(document).ready(function() {
	var fixHelper = function(e, ui) {
		ui.children().each(function() {
			$(this).width($(this).width());
		});
		return ui;
	};
    $( ".tblsort tbody" ).sortable({
		helper: fixHelper,
        opacity: 0.8, 
        cursor: 'move', 
        tolerance: 'pointer',  
        items:'tr',
        placeholder: 'state', 
        forcePlaceholderSize: true,
        update: function(event, ui){
            $.ajax({
                url: "/admin/goods/chg_order_ajax",
                type: 'POST',
                data: $(this).sortable("serialize"), 
            });
//-------------------------------                                
            }
                
        });

		$( ".tblsort tbody" ).disableSelection();
	});  
	</script>
 </head>
<body>
			   <style type="text/css">
   .btn-primary{
   background: #005a97;
   }
body {
color: #333333;
font-family: HeliosThin;
padding:0; outline:none;
margin: 0 auto;
}
body a {
color: #333333;
text-decoration: none;
}
#n {
color: #035da2;
font-size: 45px;
float: left;
margin-top: 20px;
}
#ewabuy {
font-size: 36px;
margin-left:-8.2px;
float: left;
margin-top: 20px;
}
#header {
width: 800px;
margin: 0 auto;
}
#headmenu {
width: 800px;
margin: 0 auto;
font-size: 12px;
font-family: Arial;
clear:both;
}
#headbg {
background: #333333;
height: 50px;
padding:0; outline:none;
margin-top: 10px;
}
#podlogo {
font-size: 11px;
margin-top:  52px;
}
#float {
}
#link {

}
#link a{
color: #fff;
margin-top: 17px;
float:left;
}
#right {
position: absolute;
width: 220px;
right: 0;
}
#content {
margin-right: 130px;
margin-top: 15px;
width:530px;
font-size: 12px;
font-family: Arial;
}
#inf {
margin: 0 auto;
width:800px;
 position: relative;
 font-family: Arial;
} 
.table thead > tr > th, .table tbody > tr > th, .table tfoot > tr > th, .table thead > tr > td, .table tbody > tr > td, .table tfoot > tr > td {
border-top: 0px solid #ffffff;
}
.btn {
background: #457cbc;
}
.btn:hover {
background: #72aae7;
}

body {
background: #f3f3f3 repeat-x;
color: #bebebe;
font-family: Tahoma, Arial, Helvetica, sans-serif;
font-size: 11px;
margin: 0;
}

table tr:hover td {
background: #FFFFFF;
color: #000000;
}
</style>
<div style="padding-top: 10px; padding-bottom: 10px;" class="modal-body">
<? echo validation_errors(); ?>
<? echo form_open(); ?>
<table style="margin-bottom: 0px; margin-left: 0px; margin-right: 0px;" class="table">
	<tr style="display: table;margin-left: 120px; margin-right: 152px;">
		<td>E-mail:</td>
		<td><input style="margin-left: 8px;" <? echo form_input('email'); ?></input></td>
	</tr>
	<tr style="display: table;margin-left: 120px; margin-right: 152px;">
		<td>Пароль:</td>
		<td><? echo form_password('password'); ?></td>
	</tr>
	<tr style="display: table;">
		<td></td>
		<td><input style="margin-left: 285px;" <? echo form_submit('submit','Войти','class="btn btn-primary"'); ?></input></td>
	</tr>
</table>
<? echo form_close(); ?>
</div>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="http://newshopeasy.newabuy.ru/assets/js/bootstrap.min.js"></script>

    <!-- Enable responsive features in IE8 with Respond.js (https://github.com/scottjehl/Respond) -->
    <script src="http://newshopeasy.newabuy.ru/assets/js/respond.js"></script>
  </body>
</html>