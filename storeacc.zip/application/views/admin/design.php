﻿<h1>Настройки дизайна</h1>
<? if(isset($error)) {
		echo $error;
	}
	elseif(isset($ok)) {
		echo '<div class="alert alert-success">Данные успешно сохранены!</div>';
	}
	?>
<? echo validation_errors(); ?>
<? echo form_open_multipart(); ?>

<table class="table">
	<tr>
		<td>Логотип:</td>
		<td><? echo form_input('site_logo', set_value('site_logo', $this->config->item('site_logo')),'class="form-control"'); ?></td>
	</tr>
	<tr>
		<td>Нижний Логотип:</td>
		<td><? echo form_input('site_flogo', set_value('site_flogo', $this->config->item('site_flogo')),'class="form-control"'); ?></td>
	</tr>
	<tr>
		<td>Картинка на фон:</td>
		<td><? echo form_input('sitefon', set_value('sitefon', $this->config->item('sitefon')),'class="form-control"'); ?></td>
	</tr>
    <tr>
		<td>Информация:</td>
		<td><? echo form_textarea('site_pinfo', set_value('site_pinfo', $this->config->item('site_pinfo')),'class="tinymce"'); ?></td>
	</tr>
        <tr>
		<td>Контакты:</td>
		<td><? echo form_textarea('site_infokontakt', set_value('site_infokontakt', $this->config->item('site_infokontakt')),'class="tinymce"'); ?></td>
	</tr>
        <tr style="display:none;">
		<td>Вид показа товара:</td>
		<td><? echo form_dropdown('site_tptovar', array('0'=>'Линейный','1'=>'Сеточный','2'=>'PrimeArea','3'=>'DigiSeller'), $this->config->item('site_tptovar')); ?></td>
	</tr>
        <tr style="display:none;">
		<td>Тип показа товара:</td>
		<td><? echo form_dropdown('vptsite', array('1'=>'В странице','2'=>'В окне (popup)'), $this->config->item('vptsite')); ?></td>
	</tr>
	<tr>
		<td></td>
		<td><? echo form_submit('submit','Сохранить','value="upload" class="btn btn-primary"'); ?></td>
	</tr>
	</table>
<? echo form_close(); ?>
