﻿<h1><p class="lead pull-left">Товары</p></h1>
<? echo anchor('admin/goods/edit','<i class="glyphicon glyphicon-plus"></i> Добавить товар',array('class'=>'pull-right btn btn-small btn-primary')); ?>
<div class="clearfix"></div>

<table style="width:100%;" class="table tblsort table-hover table-bordered">
	<thead>
		<th>ID</th>
		<th>Название</th>
		<th>Кол-во</th>
		<th>Цена</th>
		<th>Изменить</th>
		<th>Удалить</th>
	</thead>
	<tbody>
<? if(count($goods)): foreach($goods as $good): ?>
		<tr id="item-<? echo $good->id; ?>">
			<td><center><a style="color: #000;text-decoration: none;" href="/admin/goods/edit/<? echo $good->id; ?>"><? echo $good->id; ?></a></center></td>
			<td><center><a style="color: #000;text-decoration: none;" href="/admin/goods/edit/<? echo $good->id; ?>"><? echo $good->name; ?></a></center></td>
			<td><center><a style="color: #000;text-decoration: none;" href="/admin/goods/edit/<? echo $good->id; ?>"><? echo $good->count; ?></a></center></td>
			<td><center><? echo $good->price_rub * $good->min_order ?> Руб за <? echo $good->min_order ?> шт</center></td>
			<td><center><? echo btn_edit('admin/goods/edit/'.$good->id); ?></center></td>
			<td><center><? echo btn_delete('admin/goods/delete/'.$good->id); ?></center></td>
		</tr>
<? endforeach; ?>
<? else: ?>
	<tr>
		<td colspan="3">Товары отсутствуют</td>
	</tr>
<? endif; ?>
	</tbody>
</table>
