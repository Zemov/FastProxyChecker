<h1><p class="lead pull-left">Страницы</p></h1>
<? echo anchor('admin/page/edit','<i class="glyphicon glyphicon-plus"></i> Добавить страницу',array('class'=>'pull-right btn btn-small btn-primary')); ?>
<div class="clearfix"></div>
<table class="table table-bordered">
	<thead>
		<th>Заголовок</th>
		<th>Изменить</th>
		<th>Удалить</th>
	</thead>
	<tbody>
<? if(count($pages)): foreach($pages as $page): ?>
		<tr>
			<td><center><? echo anchor('admin/page/edit/'.$page->id, $page->title); ?></center></td>
			<td><center><? echo btn_edit('admin/page/edit/'.$page->id); ?></center></td>
			<td><center><? echo btn_delete('admin/page/delete/'.$page->id); ?></center></td>
		</tr>
<? endforeach; ?>
<? else: ?>
	<tr>
		<td colspan="3">Записи отсутствуют</td>
	</tr>
<? endif; ?>
	</tbody>
</table>