
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<? echo site_url('/assets/js/bootstrap.min.js'); ?>"></script>

    <!-- Enable responsive features in IE8 with Respond.js (https://github.com/scottjehl/Respond) -->
    <script src="<? echo site_url('/assets/js/respond.js'); ?>"></script>
  </body>
</html>