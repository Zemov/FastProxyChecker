<h3><? echo empty($kupon->id) ? 'Создание купона' : 'Редактировать купон: ' . $kupon->kupon_name; ?></h3>
<? echo validation_errors(); ?>
<? echo form_open(); ?>
<table class="table">
	<tr>
		<td>Купон:</td>
		<td><? echo form_input('kupon_name', set_value('kupon_name', $kupon->kupon_name),'class="form-control"'); ?></td>
	</tr>
	<tr>
		<td>Процент:</td>
		<td><? echo form_input('percentage', set_value('percentage', $kupon->percentage), 'class="form-control"'); ?></td>
	</tr>
	<tr>
		<td></td>
		<td><? echo form_submit('submit','Сохранить','class="btn btn-primary"'); ?></td>
	</tr>
</table>
<? echo form_close(); ?>