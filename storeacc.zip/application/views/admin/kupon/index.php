<p class="lead pull-left">Купоны</p>
<? echo anchor('admin/kupon/edit','<i class="glyphicon glyphicon-plus"></i> Создать купон',array('class'=>'pull-right btn btn-small btn-primary')); ?>
<div class="clearfix"></div>
<table class="table table-bordered">
	<thead>
		<th>Купон</th>
                <th>Скидка</th>
		<th>Изменить</th>
		<th>Удалить</th>
	</thead>
	<tbody>
<? if(count($kupons)): foreach($kupons as $kupon): ?>
		<tr>
			<td><? echo anchor('admin/kupon/edit/'.$kupon->id, $kupon->kupon_name); ?></td>
                        <td><? echo anchor('admin/kupon/edit/'.$kupon->id, $kupon->percentage); ?></td>
			<td><? echo btn_edit('admin/kupon/edit/'.$kupon->id); ?></td>
			<td><? echo btn_delete('admin/kupon/delete/'.$kupon->id); ?></td>
		</tr>
<? endforeach; ?>
<? else: ?>
	<tr>
		<td colspan="3">Вы ещё не создавали купонов!</td>
	</tr>
<? endif; ?>
	</tbody>
</table>