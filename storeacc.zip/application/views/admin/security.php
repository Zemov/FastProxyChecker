<h1>Смена пароля</h1>
<? if(isset($error)) {
		echo $error;
	}
	elseif(isset($ok)) {
		echo '<div class="alert alert-success">Данные успешно сохранены!</div>';
	}
	?>
<? echo validation_errors(); ?>
<? echo form_open_multipart(); ?>

<table class="table">
	<tr>
		<td>Введите текущий пароль:</td>
		<td><? echo form_input('old_password', set_value('old_password'),'class="form-control"'); ?></td>
	</tr>
		<tr>
		<td>Введите новый пароль:</td>
		<td><? echo form_input('password', set_value('password'),'class="form-control"'); ?></td>
	</tr>
		<tr>
		<td>Повторите новый пароль:</td>
		<td><? echo form_input('password1', set_value('password1'),'class="form-control"'); ?></td>
	</tr>
		<tr>
		<td></td>
		<td><? echo form_submit('submit','Сохранить','value="upload" class="btn btn-primary"'); ?></td>
	</tr>
</table>
<h1>Блокировка по IP</h1>
<? echo anchor('admin/security/edit','<i class="glyphicon glyphicon-plus"></i> Заблокировать IP Адрес',array('class'=>'pull-right btn btn-small btn-primary')); ?>
<table class="table table-bordered">
	<thead>
		<th>IP адрес</th>
		<th>Дата добавления</th>
		<th>Удалить</th>
	</thead>
	<tbody>
<? if(count($ips)): foreach($ips as $page): ?>
		<tr>
			<td><? echo anchor($page->id, $page->ip); ?></td>
			<td><? echo btn_edit('admin/security/edit/'.$page->id); ?></td>
			<td><? echo btn_delete('admin/security/delete/'.$page->id); ?></td>
		</tr>
<? endforeach; ?>
<? else: ?>
	<tr>
		<td colspan="3">Записи отсутствуют</td>
	</tr>
<? endif; ?>
	</tbody>
</table>
<? echo form_close(); ?>
