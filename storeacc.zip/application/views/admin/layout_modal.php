<? $this->load->view('admin/components/adm_head')?>
<body>
	<div class="modal-dialog">
		<div class="modal-content">
			<? $this->load->view($subview); ?>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
<? $this->load->view('admin/components/adm_foot')?>