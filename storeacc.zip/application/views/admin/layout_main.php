﻿<? $this->load->view('admin/components/adm_head')?>
  <body>
<div class="wrap">
	<div id="header">
<div id="update"><a href="/admin/orders"><div id="update_btn"><div style="padding:3px;text-align:center;margin-right:2px;">Заказы</div></div></a>
<a href="/admin/security"><div id="profile_btn"><div style="padding:3px;text-align:center;">Мой профиль</div></div></a>
 <div id="usd_curs">USD ЦБ
   42.6525</div><div id="usd_curs">EUR ЦБ
54.3393</div><div id="usd_curs">UAH ЦБ
3.28096</div>
</div>
<div id="headbg"><div style="width:1100px;margin:0 auto;">
<a href="/admin/goods"><div id="head"><div style="margin-left:5px;" id="head_url">Главная страница</div></div></a>
<a href="/admin/goods/edit"><div id="head"><div id="head_url">Добавить товар</div></div></a>
<a href="/admin/kupon/edit"><div id="head"><div id="head_url">Добавить купон</div></div></a>
<a href="/admin/bloks"><div id="head"><div id="head_url">Блоки</div></div></a>
<a href="/admin/config"><div id="head"><div id="head_url">Настройки</div></div></a>
<a href="/admin/categories"><div id="head"><div id="head_url">Категории</div></div></a>
<a href="/admin/design"><div id="head"><div id="head_url">Дизаин</div></div></a>
<a href="/admin/config"><div id="head"><div id="head_url">Оплата</div></div></a>
<a id="head_url_exit" href="/admin/user/logout/"><div id="head_exit"><b><div style="padding:15px;">Выйти</div></b></div></a>
		    </div>
		</div>
	</div>
	
	<div id="content">
		<div id="sidebar">
			<div class="box">
				<div class="h_title">&#8250; Контроль</div>
				<ul id="home">
					<li class="b1"><a class="icon view_page" href="/" target="_blank">Открыть магазин</a></li>
					<li class="b2"><a class="icon report" href="/admin/goods">Товары</a></li>
                                                                      <li class="b2"><a class="icon report" href="/admin/kupon">Купоны</a></li>
                                        <li class="b1"><a class="icon category" href="/admin/categories">Категории</a></li>
					<li class="b2"><a class="icon add_page" href="/admin/goods/edit">Добавить товар</a></li>

                                        <li class="b1"><a class="icon users" href="/admin/orders">Заказы</a></li>
                                        <li class="b2"><a class="icon block_users" href="/admin/stat">Статистика</a></li>					<li class="b2"><a class="icon config" href="/admin/config">Настройки</a></li>
				</ul>
			</div>
			
			<div class="box">
				<div class="h_title">&#8250; Дизайн</div>
				<ul>
					<li class="b1"><a class="icon page" href="/admin/design">Управление дизайном</a></li>
					<li class="b2"><a class="icon category"  href="/admin/page/">Страницы</a></li>
					<li class="b1"><a class="icon add_page" href="/admin/page/edit">Добавить страницу</a></li>
				</ul>
			</div>
			<div class="box">
				<div class="h_title">&#8250; Пользователь</div>
				<ul>
					<li class="b1"><a class="icon users" href="/admin/security">Смена пароля</a></li>
                                        <li class="b1"><a class="icon block_users" href="/admin/security">Заблокированные IP</a></li>
                                        <li class="b1"><a class="icon add_page" href="/admin/security/edit">Заблокировать IP</a></li>
				</ul>
			</div>
			<div class="box">
				<div class="h_title">&#8250; Управление</div>
				<ul>
					<li class="b1"><a class="icon config" href="/admin/bloks">Управление блоками</a></li>
				</ul>
			</div>
		<div class="box">
				<div class="h_title">&#8250; Администратор</div>
				<ul>
					<li class="b1"><a class="icon view_page" href="https://vk.com/rikogg" target="_blank">Vk.com</a></li>
					<li class="b1"><a class="icon view_page" href="skype:kirgr02?call" target="_blank">Skype</a></li>
				</ul>
			</div>
		</div>
		<div id="main">

			<div class="clear"></div>
			
			<div class="full_w">
			<div class="<? echo $subview == 'admin/orders' ? 'col-lg-12' : 'col-lg-8';?>">
			<? empty($subview) ? "" : $this->load->view($subview)  ?>
			<? if($subview != 'admin/orders'): ?>
			</div>
		</div>
		<div class="clear"></div>
	</div>
			<? endif; ?>
<div id="footer">
		<div class="left">
			<p>Админ панель: <? echo $this->config->item('site_name'); ?></p>
		</div>
<div class="right">
			<p>TopHacks © 2016</p>
		</div>
	</div>
</div>
<? $this->load->view('admin/components/adm_foot'); ?>

<style>
#sidebar .box .h_title {
background: url(/goodakk/b-nav.png) no-repeat 0 0;
cursor: pointer;
color: #fff;
font-size: 14px;
font-family: tahoma;
width: 151px;
height: 36px;
padding-left: 38px;
padding-top: 11px;
margin-left: -1px;
text-shadow: #5403FF 0px 1px 1px;
display: block;
}

#footer {
background: #F00;
border-top: 0px solid #404345;
color: #FFFFFF;
float: left;
margin: 0 auto;
font-weight: bold;
padding: 8px 20px;
text-shadow: #5403FF 0px 1px 1px;
width: 860px;
}

table th {
background: #F00;
color: #fff;
border-left: 1px solid #ffffff;
border-right: 1px solid #ffffff;
font-size: 11px;
font-weight: bold;
padding: 7px;
text-shadow: 0px 1px #5403FF;
}

.btn-primary {
color: #fff;
background-color: #F00;
border-color: #F00;
float: right!important;
margin-right: 15px;
}

</style>
	<style>
#sidebar {
height: 800px;
background-color: #f3f3f3;
margin: 0;
-webkit-border-bottom-left-radius: 6px;
-moz-border-radius-bottomleft: 6px;
border-bottom-left-radius: 0px;
-webkit-box-shadow: inset -3px 5px 10px 1px rgba(0,0,0,.03);
-moz-box-shadow: inset -3px 5px 10px 1px rgba(0,0,0,.03);
box-shadow: inset -3px 5px 10px 1px rgba(0,0,0,.03);
}

table {
font-size: 11px;
}

#header #nav {
padding-top: 0px;
}

#headbg {
position: relative;
width: 100%;
z-index: 999;
padding: 0;
outline: none;
margin-top: 15px;
height: 46px;
background: #313e51;
font-size: 11px;
}

</style>
<style>
body {
background: #ecf0f1;
color: #111111;
font-family: Arial, Tahoma;
font-size:12px;
}
#container {
width:1100px;
min-height:700px;
background: #fff;
margin: 0 auto;
margin-top:60px;
}
#header {
width:1100px;
min-height: 0px;
background: #ecf0f1;
margin: 0 auto;
}
#logo {
margin-top:5px;
}
#headbg {
position: relative;
width: 100%;
z-index:999;
padding:0; outline:none;
margin-top:15px;
height:46px;
background: #313e51;
font-size:11px;
}
#head {
float:left;
}
#head:hover{
background: #5f6c7f;
height:46px;
}
#head_url {
padding:7px;
margin-top:8px;
color:#fff;
}
#head_url a{
text-decoration:none;
color: #fff;
}
#head_exit {
float:right;
background: #e7371c;
height:46px;
margin-top: 0px;
position: relative;
}
#head_exit:hover{
background: #d01527;
}
#head_url_exit {
padding:7px;
margin-top:8px;
color:#fff;
}
#head_url_exit:hover{
text-decoration:none;
color: #fff;
height:46px;
}
#update {
padding:30px;
}
#ico_update_0 {
width:107px;
float:right;
height:16px;
margin-right:-10px;
}
#ico_update_0:hover{
}
#ico_wiki {
width:65px;
float:right;
height:16px;
margin-right:20px;
}
#ico_wiki:hover{
}
#footer {
color: #5c5c5c;
height:20px;
width:100%;
text-align:center;
font-size:11px;
margin-top:5px;
}
#footer a{
color: #0974b8;
text-decoration: none;
}
#left {
float:left;
padding:10px;
font-size:11px;
width:220px;
}
#right {
float:left;
padding:10px;
width:795px;
}
#notice {
    background: none repeat scroll 0 0 #d81321;
    border-radius: 10px;
    color: #fff;
    height: 16px;
	float:right;
	margin-left:20px;
    margin-top: -20px;
    width: 16px;
}
	@-moz-document url-prefix()
	{
	#moz {
	margin-top:17px;
	}
	}
	
.btn {
background: #457cbc;
}
.btn:hover {
background: #72aae7;
}
#update_btn {
float:right;
  color: #fff;
width:99px;
background: #313e51;
  height:20px;
  font-size:11px;
  margin-right:-30px;
  border-radius:2px;
}
#update_btn {
text-decoration:none;
    color: #fff;
  }
#update_btn:hover{
background: #606d80;
  }
#update_btn_yea {
float:right;
color: #fff;
width:95px;
background: #e7371c;
  height:20px;
  font-size:11px;
  margin-right:-30px;
  border-radius:2px;
}
  #update_btn_yea {
text-decoration:none;
    color: #fff;
  }
  #update_btn_yea:hover{
background: #d01527;
  }
  #wiki_btn {
float:right;
  color: #fff;
width:45px;
  height:20px;
  font-size:11px;
  margin-right:10px;
  background: #313e51;
  border-radius:2px;
}
  #wiki_btn {
text-decoration:none;
    color: #fff;
  }
  #wiki_btn:hover{
background: #606d80;
  }
  #profile_btn {
float:right;
  color: #fff;
width:95px;
  height:20px;
  font-size:11px;
  margin-right:10px;
  background: #313e51;
  border-radius:2px;
}
  #profile_btn {
text-decoration:none;
    color: #fff;
  }
  #profile_btn:hover{
background: #606d80;
  }
      #usd_curs {
float:left;
      color:#606d80;
  font-size:11px;
  margin-left:40px;
  margin-top:5px;
}
.tabs-content {
    width:960px;
    height:300px;
    overflow:hidden;
}
.tabs-content ul {
    list-style: none
    /* Эти 3 линии для Opera */
    height: 320px;
    overflow: scroll;
    overflow-y: hidden;
}
.tabs-content ul li {
    width:960px;
    height:300px;
}
</style>
<style>
.col-lg-8 {
width: 100%;
}

.btn-primary {
color: #fff;
background-color: #457cbc;
border-color: #457cbc;
float: right!important;
margin-right: 15px;
}

table th {
text-align: center;
}
</style>