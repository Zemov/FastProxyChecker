﻿<?php
class kupon_model extends MY_Model
{

    protected $table_name = "kupons";
    protected $order_by = "order";
    public $rules = array( 'kupon_name' => array( 'field' => "kupon_name", 'label' => "Купон", 'rules' => "trim|required|max_length[100]|xss_clean" ), 'percentage' => array( 'field' => "percentage", 'label' => "Процент", 'rules' => "trim|required" ) );

    public function get_new( )
    {
        $kupon->kupon_name = "";
        $kupon->percentage = "";
        return $kupon;
    }

    public function get_nested( )
    {
        if ( count( $table ) )
        {
            foreach ( $table as $key => $item )
            {
                $ret[] = array( "kupon_name" => $item->kupon_name, "percentage" => $item->percentage );
            }
        }
        else
        {
            $ret = "Записи отсутствуют!";
        }
        return $ret;
    }

}

?>