<?php
/**
 * User: mdv
 * Date: 08.04.12
 * Time: 22:58
 */
class YM_ApiConnectionError extends YM_Error {

}
