<?php

class YM_InvalidTokenError extends YM_Error {

}
