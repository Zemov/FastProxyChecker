<?php
/**
 * User: mdv
 * Date: 08.04.12
 * Time: 23:39
 */
class YM_ApiError extends YM_Error {

}
