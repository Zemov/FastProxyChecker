<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require('qiwi-class.php');

function qiwi_pay($qiwi_num,$qiwi_pass,$bill,$price)
{
	$qiwi = new QIWI_LazyPay($qiwi_num,$qiwi_pass);
	$date1 = date('d.m.Y',strtotime('-1 day'));
	$date2 = date('d.m.Y',strtotime('+1 day'));
	$operations = $qiwi->GetHistory($date1,$date2);
	foreach($operations as $operation)
	{
		$curcheck = 0;
		$cur = trim(preg_replace('/[^a-zа-я\s]/ui', '', $operation['sAmount']));
		if($cur == "руб") {
			$curcheck = 1;
		}
		if($curcheck == 1 && number_format($operation['dAmount'], 2, '.', '') == $price && $operation['sComment'] == $bill && $operation['sStatus'] == "status_SUCCESS")
		{
			return 1;
		}
	}
}

function check_qiwi($qiwi_num,$qiwi_pass)
{
	try {
		$qiwi = new QIWI_LazyPay($qiwi_num,$qiwi_pass);
		$date1 = date('d.m.Y',strtotime('-100 day'));
		$date2 = date('d.m.Y',strtotime('+100 day'));
		$operations = $qiwi->GetHistory($date1,$date2);
		return $operations;
	} catch (Exception $e) {
		die($e->getMessage());
	}
}
?>