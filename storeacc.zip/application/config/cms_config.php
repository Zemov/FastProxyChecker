<?
$config['sitename'] = 'Каталог товаров';
?>